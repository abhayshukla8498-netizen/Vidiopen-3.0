import subprocess
import os

def run_cmd(cmd):
    p = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if p.returncode != 0:
        print(f"Error running: {cmd}\n{p.stderr}")
    return p.returncode == 0

# We will composite layers using ImageMagick 6
w, h = 512, 512

# 1. Base dark squircle
cmd1 = f"""
convert -size {w}x{h} xc:transparent \
  -fill '#080811' -stroke none -draw "roundrectangle 16,16,495,495 110,110" \
  /tmp/base_squircle.png
"""
run_cmd(cmd1)

# 2. Glowing border
# We generate a 4-corner gradient or sweep-like glow
cmd2 = f"""
convert -size {w}x{h} xc:transparent \
  -stroke '#FF5500' -strokewidth 12 -fill none -draw "roundrectangle 18,18,493,493 108,108" \
  -blur 0x10 /tmp/glow_orange.png
"""
run_cmd(cmd2)

cmd3 = f"""
convert -size {w}x{h} xc:transparent \
  -stroke '#00D4FF' -strokewidth 12 -fill none -draw "roundrectangle 18,18,493,493 108,108" \
  -blur 0x10 /tmp/glow_cyan.png
"""
run_cmd(cmd3)

print("Base layers created")
