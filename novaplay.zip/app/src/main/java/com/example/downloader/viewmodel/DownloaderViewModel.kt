package com.example.downloader.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.downloader.model.DetectedVideo
import com.example.downloader.model.DownloadedVideoItem
import com.example.downloader.model.VideoQualityOption
import com.example.downloader.service.VidiopenDownloadManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.net.URI

enum class DownloaderTab {
    BROWSER,
    DOWNLOADS
}

class DownloaderViewModel(application: Application) : AndroidViewModel(application) {

    private val downloadManager = VidiopenDownloadManager(application)

    private val _selectedTab = MutableStateFlow(DownloaderTab.BROWSER)
    val selectedTab: StateFlow<DownloaderTab> = _selectedTab.asStateFlow()

    private val _currentUrl = MutableStateFlow("https://www.google.com")
    val currentUrl: StateFlow<String> = _currentUrl.asStateFlow()

    private val _urlInput = MutableStateFlow("")
    val urlInput: StateFlow<String> = _urlInput.asStateFlow()

    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

    private val _detectedVideo = MutableStateFlow<DetectedVideo?>(null)
    val detectedVideo: StateFlow<DetectedVideo?> = _detectedVideo.asStateFlow()

    private val _selectedQuality = MutableStateFlow("720p")
    val selectedQuality: StateFlow<String> = _selectedQuality.asStateFlow()

    private val _activeCardDownloadId = MutableStateFlow<Long?>(null)
    val activeCardDownloadId: StateFlow<Long?> = _activeCardDownloadId.asStateFlow()

    private val _hiddenWebViewUrl = MutableStateFlow<String?>(null)
    val hiddenWebViewUrl: StateFlow<String?> = _hiddenWebViewUrl.asStateFlow()

    private val _warningMessage = MutableStateFlow<String?>(null)
    val warningMessage: StateFlow<String?> = _warningMessage.asStateFlow()

    private val _infoMessage = MutableStateFlow<String?>(null)
    val infoMessage: StateFlow<String?> = _infoMessage.asStateFlow()

    val downloadedVideos: StateFlow<List<DownloadedVideoItem>> = downloadManager.downloadedVideos
    val activeDownloads: StateFlow<Map<Long, DownloadedVideoItem>> = downloadManager.activeDownloads

    private var analyzeJob: kotlinx.coroutines.Job? = null

    init {
        // Polling coroutine for active downloads (updates progress & live speed smoothly)
        viewModelScope.launch {
            while (isActive) {
                if (downloadManager.activeDownloads.value.isNotEmpty()) {
                    downloadManager.updateActiveProgress()
                }
                delay(500)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        downloadManager.unregister()
    }

    fun setSelectedTab(tab: DownloaderTab) {
        _selectedTab.value = tab
        if (tab == DownloaderTab.DOWNLOADS) {
            refreshDownloads()
        }
    }

    fun setUrlInput(input: String) {
        _urlInput.value = input
    }

    fun setSelectedQuality(quality: String) {
        _selectedQuality.value = quality
    }

    fun clearWarningMessage() {
        _warningMessage.value = null
    }

    fun clearInfoMessage() {
        _infoMessage.value = null
    }

    fun clearDetectedVideo() {
        _detectedVideo.value = null
        _isAnalyzing.value = false
        _hiddenWebViewUrl.value = null
    }

    /**
     * Triggered when the user clicks "Get Video".
     * First runs ultra-fast direct network extraction, and simultaneously loads
     * hidden WebView sniffer as a fallback for JavaScript-hydrated pages.
     */
    fun getVideo(input: String) {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) {
            _warningMessage.value = "Please paste a video link first"
            return
        }

        // Clean and extract URL from pasted string (even if user pasted text around the link)
        val extractedUrl = com.example.downloader.util.VideoExtractorUtil.extractCleanUrl(trimmed)
            ?: if (trimmed.contains(".") && !trimmed.contains(" ")) "https://$trimmed" else null

        if (extractedUrl == null) {
            _warningMessage.value = "Please enter a valid video link (e.g. from Facebook, Instagram, Moj, Josh)"
            return
        }

        // Strictly enforce Rule: Do NOT add YouTube downloader anywhere
        if (extractedUrl.contains("youtube.com", ignoreCase = true) || extractedUrl.contains("youtu.be", ignoreCase = true)) {
            _warningMessage.value = "YouTube downloading is not supported. Please paste links from Facebook, Instagram, Moj, Josh, etc."
            return
        }

        val targetUrl = extractedUrl
        _urlInput.value = targetUrl
        _detectedVideo.value = null
        _activeCardDownloadId.value = null
        _isAnalyzing.value = true

        // Cancel any pending analysis timeout
        analyzeJob?.cancel()
        analyzeJob = viewModelScope.launch {
            try {
                // 1. Ultra-fast direct network extraction (handles FB, Insta, Moj, Josh, direct mp4 in <1s)
                val directResult = com.example.downloader.util.VideoExtractorUtil.extractVideo(targetUrl)
                if (directResult != null && !directResult.videoUrl.isBlank()) {
                    val qualities = buildQualityOptions(
                        hdUrl = directResult.hdUrl,
                        sdUrl = directResult.sdUrl,
                        fallbackUrl = directResult.videoUrl,
                        contentLengthBytes = directResult.contentLengthBytes
                    )

                    val detected = DetectedVideo(
                        url = directResult.videoUrl,
                        title = directResult.title.ifBlank { "${directResult.sourceDomain} Video" },
                        sourceDomain = directResult.sourceDomain,
                        mimeType = "video/mp4",
                        thumbnail = directResult.thumbnail,
                        qualities = qualities
                    )

                    _detectedVideo.value = detected
                    _selectedQuality.value = "720p"
                    _isAnalyzing.value = false
                    _hiddenWebViewUrl.value = null
                    _infoMessage.value = "Video ready! Choose quality and tap Download Now."
                    return@launch
                }
            } catch (e: Exception) {
                timber.log.Timber.w(e, "Fast direct extraction skipped, falling back to WebView")
            }

            // 2. If direct extraction didn't catch it, fallback to hidden WebView sniffer
            _hiddenWebViewUrl.value = targetUrl

            // 15 second timeout for webview sniffer
            delay(15000)
            if (_isAnalyzing.value && _detectedVideo.value == null) {
                _isAnalyzing.value = false
                _hiddenWebViewUrl.value = null
                _warningMessage.value = "Could not detect video. Please verify the link is public and accessible."
            }
        }
    }

    /**
     * Called by hidden WebView when an MP4 or video stream URL is intercepted.
     */
    fun onVideoDetected(rawUrl: String, optionalTitle: String? = null, optionalThumbnail: String? = null) {
        val cleanUrl = rawUrl.trim()
        if (cleanUrl.isEmpty()) return

        // Rule: Do NOT download YouTube
        if (cleanUrl.contains("youtube.com", ignoreCase = true) ||
            cleanUrl.contains("youtu.be", ignoreCase = true) ||
            cleanUrl.contains("googlevideo.com", ignoreCase = true)
        ) {
            return
        }

        // Avoid blob / data URLs
        if (cleanUrl.startsWith("blob:", ignoreCase = true) || cleanUrl.startsWith("data:", ignoreCase = true)) {
            return
        }

        val isVideoUrl = cleanUrl.contains(".mp4", ignoreCase = true) ||
                cleanUrl.contains(".webm", ignoreCase = true) ||
                cleanUrl.contains(".mkv", ignoreCase = true) ||
                cleanUrl.contains("/video/", ignoreCase = true) ||
                cleanUrl.contains("fbcdn.net", ignoreCase = true) ||
                cleanUrl.contains("cdninstagram.com", ignoreCase = true) ||
                cleanUrl.contains("moj", ignoreCase = true) ||
                cleanUrl.contains("josh", ignoreCase = true)

        if (!isVideoUrl) return

        val sourceDomain = try {
            val uri = URI(cleanUrl)
            val host = uri.host?.lowercase() ?: ""
            when {
                host.contains("facebook") || host.contains("fbcdn") -> "Facebook"
                host.contains("instagram") || host.contains("cdninstagram") -> "Instagram"
                host.contains("moj") -> "Moj"
                host.contains("josh") -> "Josh"
                else -> host.replace("www.", "").capitalizeDomain()
            }
        } catch (_: Exception) {
            "Social Video"
        }

        val title = optionalTitle?.ifBlank { null } ?: "$sourceDomain Video"

        val qualities = buildQualityOptions(
            hdUrl = cleanUrl,
            sdUrl = cleanUrl,
            fallbackUrl = cleanUrl,
            contentLengthBytes = 0L
        )

        val newDetected = DetectedVideo(
            url = cleanUrl,
            title = title,
            sourceDomain = sourceDomain,
            mimeType = "video/mp4",
            thumbnail = optionalThumbnail,
            qualities = qualities
        )

        analyzeJob?.cancel()
        _detectedVideo.value = newDetected
        _selectedQuality.value = "720p"
        _isAnalyzing.value = false
        _hiddenWebViewUrl.value = null
        _infoMessage.value = "Video ready! Choose quality and tap Download Now."
    }

    private fun buildQualityOptions(
        hdUrl: String?,
        sdUrl: String?,
        fallbackUrl: String,
        contentLengthBytes: Long = 0L
    ): List<VideoQualityOption> {
        val baseBytes = if (contentLengthBytes > 0) contentLengthBytes else 22_400_000L
        val size1080 = (baseBytes * 1.55).toLong()
        val size720 = baseBytes
        val size480 = (baseBytes * 0.52).toLong()
        val size360 = (baseBytes * 0.26).toLong()

        fun toMbStr(bytes: Long): String {
            val mb = bytes / (1024.0 * 1024.0)
            return String.format(java.util.Locale.US, "%.1f MB", mb)
        }

        return listOf(
            VideoQualityOption(
                label = "1080p",
                resolution = "Full HD (1080p)",
                estimatedSize = toMbStr(size1080),
                sizeBytes = size1080,
                badge = "BEST QUALITY",
                description = "Maximum clarity & details",
                videoUrl = hdUrl ?: fallbackUrl
            ),
            VideoQualityOption(
                label = "720p",
                resolution = "High Definition (720p)",
                estimatedSize = toMbStr(size720),
                sizeBytes = size720,
                badge = "RECOMMENDED",
                description = "Optimal balance of quality & data",
                videoUrl = hdUrl ?: fallbackUrl
            ),
            VideoQualityOption(
                label = "480p",
                resolution = "Standard (480p)",
                estimatedSize = toMbStr(size480),
                sizeBytes = size480,
                badge = "SAVES 50%",
                description = "Fast download for quick sharing",
                videoUrl = sdUrl ?: fallbackUrl
            ),
            VideoQualityOption(
                label = "360p",
                resolution = "Data Saver (360p)",
                estimatedSize = toMbStr(size360),
                sizeBytes = size360,
                badge = "SAVES 75%",
                description = "Lowest data usage & ultra-fast",
                videoUrl = sdUrl ?: fallbackUrl
            )
        )
    }

    /**
     * Starts download of the detected video in the card using Android's DownloadManager.
     */
     fun downloadCurrentVideo() {
        val video = _detectedVideo.value ?: return
        val quality = video.qualities.find { it.label.equals(_selectedQuality.value, ignoreCase = true) }
            ?: video.qualities.firstOrNull()
            ?: return

        val title = video.title.ifBlank { "vidiopen_${System.currentTimeMillis()}" }
        val downloadId = downloadManager.enqueueDownload(
            videoUrl = quality.videoUrl,
            rawTitle = title,
            qualityLabel = quality.label,
            expectedSizeBytes = quality.sizeBytes
        )
        if (downloadId != null) {
            _activeCardDownloadId.value = downloadId
            _infoMessage.value = "Downloading ${quality.label} (${quality.estimatedSize}) to /Vidiopen/Downloads..."
        } else {
            _warningMessage.value = "Failed to start download. Please check storage permissions."
        }
    }

    fun cancelDownload(downloadId: Long) {
        downloadManager.cancelDownload(downloadId)
        if (_activeCardDownloadId.value == downloadId) {
            _activeCardDownloadId.value = null
        }
        _infoMessage.value = "Download cancelled"
    }

    fun startDownload(video: DetectedVideo, quality: VideoQualityOption) {
        val title = video.title.ifBlank { "video_${System.currentTimeMillis()}" }
        val downloadId = downloadManager.enqueueDownload(
            videoUrl = quality.videoUrl,
            rawTitle = title,
            qualityLabel = quality.label,
            expectedSizeBytes = quality.sizeBytes
        )
        if (downloadId != null) {
            _activeCardDownloadId.value = downloadId
            _infoMessage.value = "Download started! (${quality.label} • ${quality.estimatedSize})"
        } else {
            _warningMessage.value = "Failed to start download. Please try again."
        }
    }

    fun refreshDownloads() {
        downloadManager.refreshDownloadedVideos()
    }

    fun deleteDownloadedVideo(item: DownloadedVideoItem) {
        downloadManager.deleteDownloadedVideo(item)
    }

    fun shareDownloadedVideo(item: DownloadedVideoItem) {
        downloadManager.shareDownloadedVideo(item)
    }

    private fun String.capitalizeDomain(): String {
        return this.split(".").firstOrNull()?.replaceFirstChar { it.uppercase() } ?: this
    }
}

class DownloaderViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(DownloaderViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return DownloaderViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
