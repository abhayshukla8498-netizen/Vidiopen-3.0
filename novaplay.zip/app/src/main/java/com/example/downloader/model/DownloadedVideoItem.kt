package com.example.downloader.model

import android.net.Uri
import java.util.Locale

enum class DownloadStatus {
    DOWNLOADING,
    COMPLETED,
    FAILED,
    PAUSED
}

data class DownloadedVideoItem(
    val id: String,
    val fileName: String,
    val filePath: String,
    val fileUri: Uri? = null,
    val fileSizeBytes: Long = 0L,
    val expectedSizeBytes: Long = 0L,
    val downloadedBytes: Long = 0L,
    val dateDownloaded: Long = System.currentTimeMillis(),
    val durationMs: Long = 0L,
    val downloadId: Long? = null,
    val status: DownloadStatus = DownloadStatus.COMPLETED,
    val progressPercent: Int = 100,
    val thumbnailUri: String? = null,
    val speedBytesPerSec: Long = 0L,
    val lastUpdateTimestamp: Long = System.currentTimeMillis(),
    val qualityLabel: String = "720p"
) {
    val effectiveSizeBytes: Long
        get() = if (fileSizeBytes > 0L) fileSizeBytes else expectedSizeBytes

    val formattedSize: String
        get() {
            val bytes = effectiveSizeBytes
            if (bytes <= 0) return "Unknown size"
            val kb = bytes / 1024.0
            val mb = kb / 1024.0
            val gb = mb / 1024.0
            return when {
                gb >= 1.0 -> String.format(Locale.US, "%.2f GB", gb)
                mb >= 1.0 -> String.format(Locale.US, "%.1f MB", mb)
                else -> String.format(Locale.US, "%.0f KB", kb)
            }
        }

    val formattedSpeed: String
        get() {
            if (speedBytesPerSec <= 0) return "Connecting..."
            val kb = speedBytesPerSec / 1024.0
            val mb = kb / 1024.0
            return if (mb >= 1.0) {
                String.format(Locale.US, "%.1f MB/s", mb)
            } else {
                String.format(Locale.US, "%.0f KB/s", kb)
            }
        }

    val formattedProgressMb: String
        get() {
            val dlMb = downloadedBytes / (1024.0 * 1024.0)
            val totalBytes = effectiveSizeBytes
            val totalMb = totalBytes / (1024.0 * 1024.0)
            return if (totalBytes > 0) {
                String.format(Locale.US, "%.1f MB / %.1f MB", dlMb, totalMb)
            } else if (downloadedBytes > 0) {
                String.format(Locale.US, "%.1f MB downloaded", dlMb)
            } else {
                "0.0 MB"
            }
        }

    val remainingBytes: Long
        get() {
            val total = effectiveSizeBytes
            return if (total > downloadedBytes) total - downloadedBytes else 0L
        }

    val etaSeconds: Long
        get() {
            return if (speedBytesPerSec > 0 && remainingBytes > 0) {
                remainingBytes / speedBytesPerSec
            } else {
                0L
            }
        }

    val formattedEta: String
        get() {
            if (status == DownloadStatus.COMPLETED) return "Done"
            if (speedBytesPerSec <= 0 || etaSeconds <= 0) return "Estimating time..."
            val seconds = etaSeconds
            return when {
                seconds < 60 -> "${seconds}s remaining"
                seconds < 3600 -> {
                    val m = seconds / 60
                    val s = seconds % 60
                    "${m}m ${s}s remaining"
                }
                else -> {
                    val h = seconds / 3600
                    val m = (seconds % 3600) / 60
                    "${h}h ${m}m remaining"
                }
            }
        }

    val formattedDuration: String
        get() {
            if (durationMs <= 0) return "--:--"
            val totalSeconds = durationMs / 1000
            val minutes = totalSeconds / 60
            val remainingSeconds = totalSeconds % 60
            return String.format(Locale.US, "%02d:%02d", minutes, remainingSeconds)
        }
}
