package com.example.downloader.util

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import timber.log.Timber
import java.net.URI
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

data class ExtractedVideoResult(
    val videoUrl: String,
    val title: String,
    val thumbnail: String?,
    val sourceDomain: String,
    val hdUrl: String? = null,
    val sdUrl: String? = null,
    val contentLengthBytes: Long = 0L
)

object VideoExtractorUtil {

    private val okHttpClient = OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .callTimeout(15, TimeUnit.SECONDS)
        .build()

    private const val MOBILE_USER_AGENT = "Mozilla/5.0 (Linux; Android 14; Mobile; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36"
    private const val DESKTOP_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"

    /**
     * Extracts a clean URL from arbitrary pasted text.
     * Handles cases like: "Check this out https://instagram.com/reel/xyz123"
     */
    fun extractCleanUrl(input: String): String? {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return null

        val urlPattern = Pattern.compile("(https?://[^\\s\"'<>]+)", Pattern.CASE_INSENSITIVE)
        val matcher = urlPattern.matcher(trimmed)
        if (matcher.find()) {
            val found = matcher.group(1)?.trim() ?: return null
            return found.trimEnd('.', ',', ')', ']', '}', '"', '\'')
        }

        if (!trimmed.contains(" ") && trimmed.contains(".")) {
            val clean = trimmed.removePrefix("https://").removePrefix("http://")
            return "https://$clean"
        }

        return null
    }

    suspend fun extractVideo(rawUrl: String): ExtractedVideoResult? = withContext(Dispatchers.IO) {
        val targetUrl = extractCleanUrl(rawUrl) ?: return@withContext null

        // Rule: Strictly enforce NO YouTube downloader anywhere
        if (targetUrl.contains("youtube.com", ignoreCase = true) ||
            targetUrl.contains("youtu.be", ignoreCase = true) ||
            targetUrl.contains("googlevideo.com", ignoreCase = true)
        ) {
            return@withContext null
        }

        // 1. Direct media file check
        if (targetUrl.endsWith(".mp4", ignoreCase = true) ||
            targetUrl.endsWith(".webm", ignoreCase = true) ||
            targetUrl.endsWith(".mkv", ignoreCase = true) ||
            targetUrl.endsWith(".mov", ignoreCase = true) ||
            targetUrl.endsWith(".3gp", ignoreCase = true)
        ) {
            val fileName = targetUrl.substringAfterLast("/").substringBefore("?").ifBlank { "video" }
            return@withContext ExtractedVideoResult(
                videoUrl = targetUrl,
                title = fileName,
                thumbnail = null,
                sourceDomain = extractDomain(targetUrl),
                hdUrl = targetUrl,
                sdUrl = targetUrl
            )
        }

        try {
            // First attempt with Mobile User Agent
            val result = fetchAndParse(targetUrl, MOBILE_USER_AGENT)
            if (result != null) return@withContext result

            // Second attempt with Desktop User Agent if mobile was redirected or blocked
            return@withContext fetchAndParse(targetUrl, DESKTOP_USER_AGENT)
        } catch (e: Exception) {
            Timber.e(e, "VideoExtractorUtil: Error extracting from $targetUrl")
            null
        }
    }

    private fun fetchAndParse(targetUrl: String, userAgent: String): ExtractedVideoResult? {
        try {
            val request = Request.Builder()
                .url(targetUrl)
                .header("User-Agent", userAgent)
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,video/*,*/*;q=0.8")
                .header("Accept-Language", "en-US,en;q=0.9,hi;q=0.8")
                .header("Sec-Fetch-Mode", "navigate")
                .build()

            val response = okHttpClient.newCall(request).execute()
            val finalUrl = response.request.url.toString()
            val contentType = response.header("Content-Type")?.lowercase() ?: ""

            // If the URL directly redirected to a video stream
            if (contentType.contains("video/") || finalUrl.endsWith(".mp4", ignoreCase = true)) {
                val title = finalUrl.substringAfterLast("/").substringBefore("?").ifBlank { "Social Video" }
                return ExtractedVideoResult(
                    videoUrl = finalUrl,
                    title = title,
                    thumbnail = null,
                    sourceDomain = extractDomain(finalUrl),
                    hdUrl = finalUrl,
                    sdUrl = finalUrl
                )
            }

            val responseBody = response.body?.string() ?: return null
            val domain = extractDomain(finalUrl)

            // Extract Thumbnail
            val thumbnail = extractFirstMatch(responseBody, "property=[\"']og:image[\"']\\s+content=[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(responseBody, "content=[\"']([^\"']+)[\"']\\s+property=[\"']og:image[\"']")
                ?: extractFirstMatch(responseBody, "name=[\"']twitter:image[\"']\\s+content=[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(responseBody, "[\"']thumbnailUrl[\"']\\s*:\\s*[\"']([^\"']+)[\"']")

            // Extract Title
            val rawTitle = extractFirstMatch(responseBody, "property=[\"']og:title[\"']\\s+content=[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(responseBody, "<title>([^<]+)</title>")
                ?: "$domain Video"
            val title = cleanTitle(rawTitle)

            // 1. Facebook playable URLs (HD & SD)
            val fbHd = extractFirstMatch(responseBody, "[\"']playable_url_quality_hd[\"']\\s*:\\s*[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(responseBody, "[\"']hd_src[\"']\\s*:\\s*[\"']([^\"']+)[\"']")
            val fbSd = extractFirstMatch(responseBody, "[\"']playable_url[\"']\\s*:\\s*[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(responseBody, "[\"']sd_src[\"']\\s*:\\s*[\"']([^\"']+)[\"']")

            if (!fbHd.isNullOrBlank() || !fbSd.isNullOrBlank()) {
                val cleanHd = fbHd?.let { unescapeUrl(it) }
                val cleanSd = fbSd?.let { unescapeUrl(it) }
                val best = cleanHd ?: cleanSd!!
                return ExtractedVideoResult(
                    videoUrl = best,
                    title = title,
                    thumbnail = thumbnail?.let { unescapeUrl(it) },
                    sourceDomain = "Facebook",
                    hdUrl = cleanHd ?: cleanSd,
                    sdUrl = cleanSd ?: cleanHd
                )
            }

            // 2. OpenGraph video tag (Instagram, Moj, Josh, ShareChat, Web)
            val ogVideo = extractFirstMatch(responseBody, "property=[\"']og:video:secure_url[\"']\\s+content=[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(responseBody, "property=[\"']og:video:url[\"']\\s+content=[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(responseBody, "property=[\"']og:video[\"']\\s+content=[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(responseBody, "content=[\"']([^\"']+)[\"']\\s+property=[\"']og:video[\"']")
                ?: extractFirstMatch(responseBody, "name=[\"']twitter:player:stream[\"']\\s+content=[\"']([^\"']+)[\"']")

            if (!ogVideo.isNullOrBlank() && !ogVideo.startsWith("blob:") && !ogVideo.startsWith("data:")) {
                val cleanVideo = unescapeUrl(ogVideo)
                return ExtractedVideoResult(
                    videoUrl = cleanVideo,
                    title = title,
                    thumbnail = thumbnail?.let { unescapeUrl(it) },
                    sourceDomain = domain,
                    hdUrl = cleanVideo,
                    sdUrl = cleanVideo
                )
            }

            // 3. JSON video URLs (Instagram / Moj / Josh / ShareChat)
            val jsonVideo = extractFirstMatch(responseBody, "[\"']video_url[\"']\\s*:\\s*[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(responseBody, "[\"']downloadUrl[\"']\\s*:\\s*[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(responseBody, "[\"']mediaUrl[\"']\\s*:\\s*[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(responseBody, "[\"']videoUrl[\"']\\s*:\\s*[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(responseBody, "[\"']contentUrl[\"']\\s*:\\s*[\"']([^\"']+\\.mp4[^\"']*)[\"']")

            if (!jsonVideo.isNullOrBlank() && !jsonVideo.startsWith("blob:")) {
                val cleanVideo = unescapeUrl(jsonVideo)
                return ExtractedVideoResult(
                    videoUrl = cleanVideo,
                    title = title,
                    thumbnail = thumbnail?.let { unescapeUrl(it) },
                    sourceDomain = domain,
                    hdUrl = cleanVideo,
                    sdUrl = cleanVideo
                )
            }

            // 4. HTML5 video tag <video src="..."> or <source src="...">
            val html5Video = extractFirstMatch(responseBody, "<video[^>]+src=[\"']([^\"']+)[\"']")
                ?: extractFirstMatch(responseBody, "<source[^>]+src=[\"']([^\"']+)[\"']")

            if (!html5Video.isNullOrBlank() && !html5Video.startsWith("blob:") &&
                (html5Video.contains(".mp4", ignoreCase = true) || html5Video.contains("video", ignoreCase = true))
            ) {
                val cleanVideo = unescapeUrl(html5Video)
                return ExtractedVideoResult(
                    videoUrl = cleanVideo,
                    title = title,
                    thumbnail = thumbnail?.let { unescapeUrl(it) },
                    sourceDomain = domain,
                    hdUrl = cleanVideo,
                    sdUrl = cleanVideo
                )
            }

            // 5. Look for any https://...mp4 link inside quoted attributes
            val anyMp4 = extractFirstMatch(responseBody, "[\"'](https://[^\"'\\s]+\\.mp4[^\"'\\s]*)[\"']")
            if (!anyMp4.isNullOrBlank() && !anyMp4.contains("youtube.com")) {
                val cleanVideo = unescapeUrl(anyMp4)
                return ExtractedVideoResult(
                    videoUrl = cleanVideo,
                    title = title,
                    thumbnail = thumbnail?.let { unescapeUrl(it) },
                    sourceDomain = domain,
                    hdUrl = cleanVideo,
                    sdUrl = cleanVideo
                )
            }

            return null
        } catch (e: Exception) {
            Timber.w(e, "fetchAndParse error for $targetUrl")
            return null
        }
    }

    private fun extractFirstMatch(html: String, regexPattern: String): String? {
        return try {
            val pattern = Pattern.compile(regexPattern, Pattern.CASE_INSENSITIVE)
            val matcher = pattern.matcher(html)
            if (matcher.find()) {
                matcher.group(1)?.trim()
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun unescapeUrl(url: String): String {
        return url.replace("\\/", "/")
            .replace("\\u0026", "&")
            .replace("&amp;", "&")
            .replace("\\u0025", "%")
            .replace("\\\"", "\"")
            .replace("&quot;", "\"")
            .trim()
    }

    private fun cleanTitle(title: String): String {
        return title.replace("&amp;", "&")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .take(60)
            .trim()
    }

    private fun extractDomain(url: String): String {
        return try {
            val uri = URI(url)
            val host = uri.host?.lowercase() ?: ""
            when {
                host.contains("facebook") || host.contains("fb.") || host.contains("fbcdn") -> "Facebook"
                host.contains("instagram") || host.contains("cdninstagram") -> "Instagram"
                host.contains("moj") -> "Moj"
                host.contains("josh") -> "Josh"
                host.contains("twitter") || host.contains("x.com") || host.contains("twimg") -> "X"
                host.contains("sharechat") -> "ShareChat"
                else -> host.removePrefix("www.").substringBefore(".")
                    .replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
            }
        } catch (_: Exception) {
            "Social Video"
        }
    }
}
