package com.example.downloader.ui

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.view.ViewGroup
import android.webkit.*
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.downloader.model.DetectedVideo
import com.example.downloader.model.DownloadStatus
import com.example.downloader.model.DownloadedVideoItem
import com.example.downloader.model.VideoQualityOption
import androidx.compose.animation.core.*
import com.example.downloader.viewmodel.DownloaderViewModel
import com.example.downloader.viewmodel.DownloaderViewModelFactory
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloaderScreen(
    onPlayVideo: (File) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val application = context.applicationContext as android.app.Application
    val downloaderViewModel: DownloaderViewModel = viewModel(
        factory = DownloaderViewModelFactory(application)
    )

    val urlInput by downloaderViewModel.urlInput.collectAsState()
    val isAnalyzing by downloaderViewModel.isAnalyzing.collectAsState()
    val detectedVideo by downloaderViewModel.detectedVideo.collectAsState()
    val selectedQuality by downloaderViewModel.selectedQuality.collectAsState()
    val activeCardDownloadId by downloaderViewModel.activeCardDownloadId.collectAsState()
    val hiddenWebViewUrl by downloaderViewModel.hiddenWebViewUrl.collectAsState()

    val downloadedVideos by downloaderViewModel.downloadedVideos.collectAsState()
    val activeDownloads by downloaderViewModel.activeDownloads.collectAsState()
    val warningMessage by downloaderViewModel.warningMessage.collectAsState()
    val infoMessage by downloaderViewModel.infoMessage.collectAsState()

    val clipboardManager = LocalClipboardManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(warningMessage) {
        warningMessage?.let {
            snackbarHostState.showSnackbar(it)
            downloaderViewModel.clearWarningMessage()
        }
    }

    LaunchedEffect(infoMessage) {
        infoMessage?.let {
            snackbarHostState.showSnackbar(it)
            downloaderViewModel.clearInfoMessage()
        }
    }

    // Find if the currently detected video is downloading in activeDownloads
    val cardActiveDownload = remember(activeCardDownloadId, activeDownloads) {
        activeCardDownloadId?.let { activeDownloads[it] }
    }

    val otherActiveDownloads = remember(cardActiveDownload, activeDownloads) {
        activeDownloads.values.filter {
            (cardActiveDownload == null || it.downloadId != cardActiveDownload.downloadId) &&
            (it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.PAUSED)
        }
    }

    androidx.activity.compose.BackHandler(enabled = detectedVideo != null) {
        downloaderViewModel.clearDetectedVideo()
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(Color(0xFF10B981), Color(0xFF059669))
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Download,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Download Now",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Facebook • Instagram • Moj • Josh",
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.6f)
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { downloaderViewModel.refreshDownloads() },
                        modifier = Modifier.testTag("refresh_downloads_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh Downloads",
                            tint = Color.White.copy(alpha = 0.8f)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0F172A)
                )
            )
        },
        containerColor = Color(0xFF0A0F1D)
    ) { innerPadding ->
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp)
            ) {
                // 1. TOP: Clean input box + Paste button + Big "Get Video" button
                item(key = "top_input_section") {
                    TopInputSection(
                        urlInput = urlInput,
                        isAnalyzing = isAnalyzing,
                        onUrlChange = { downloaderViewModel.setUrlInput(it) },
                        onPaste = {
                            val clipText = clipboardManager.getText()?.text?.trim()
                            if (!clipText.isNullOrEmpty()) {
                                downloaderViewModel.setUrlInput(clipText)
                            }
                        },
                        onGetVideo = {
                            keyboardController?.hide()
                            downloaderViewModel.getVideo(urlInput)
                        }
                    )
                }

                // 2. MIDDLE: Preview Card (Appears after Get Video)
                if (isAnalyzing) {
                    item(key = "analyzing_card") {
                        AnalyzingCard()
                    }
                } else if (detectedVideo != null) {
                    item(key = "detected_video_card") {
                        VideoPreviewCard(
                            video = detectedVideo!!,
                            selectedQuality = selectedQuality,
                            activeDownload = cardActiveDownload,
                            onQualitySelected = { downloaderViewModel.setSelectedQuality(it) },
                            onDownloadNow = { downloaderViewModel.downloadCurrentVideo() },
                            onCancelDownload = { downloaderViewModel.cancelDownload(it) },
                            onPlayDownloaded = { filePath ->
                                onPlayVideo(File(filePath))
                            }
                        )
                    }
                }

                // Small Disclaimer Text (Mandatory Rule)
                item(key = "disclaimer_text") {
                    Text(
                        text = "For public videos only. Download only public videos with owner permission. We are not responsible for copyright violations.",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.45f),
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    )
                }

                // 2.5 ACTIVE ONGOING DOWNLOADS SECTION (Animated progress, speed & MB)
                if (otherActiveDownloads.isNotEmpty()) {
                    item(key = "active_downloads_header") {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF06B6D4).copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Bolt,
                                        contentDescription = null,
                                        tint = Color(0xFF06B6D4),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Active Downloads",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Surface(
                                    shape = CircleShape,
                                    color = Color(0xFF06B6D4).copy(alpha = 0.25f)
                                ) {
                                    Text(
                                        text = "${otherActiveDownloads.size}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF06B6D4),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Text(
                                text = "Live Progress & Speed",
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.5f)
                            )
                        }
                    }

                    items(
                        items = otherActiveDownloads,
                        key = { "active_${it.id}" }
                    ) { task ->
                        AnimatedDownloadProgressCard(
                            download = task,
                            onCancel = { task.downloadId?.let { id -> downloaderViewModel.cancelDownload(id) } },
                            onPlay = { filePath -> onPlayVideo(File(filePath)) }
                        )
                    }
                }

                // 3. BOTTOM: List of Downloaded Videos
                item(key = "downloaded_header") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Folder,
                                contentDescription = null,
                                tint = Color(0xFF10B981),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Downloaded Videos",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                shape = CircleShape,
                                color = Color(0xFF1E293B)
                            ) {
                                Text(
                                    text = "${downloadedVideos.size}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF10B981),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Text(
                            text = "/Vidiopen/Downloads",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.5f)
                        )
                    }
                }

                if (downloadedVideos.isEmpty()) {
                    item(key = "empty_downloads") {
                        EmptyDownloadsCard()
                    }
                } else {
                    items(
                        items = downloadedVideos,
                        key = { it.id }
                    ) { item ->
                        DownloadedVideoRow(
                            item = item,
                            onPlay = { onPlayVideo(File(item.filePath)) },
                            onShare = { downloaderViewModel.shareDownloadedVideo(item) },
                            onDelete = { downloaderViewModel.deleteDownloadedVideo(item) }
                        )
                    }
                }
            }

            // Hidden background WebView for silent MP4 detection ONLY while actively analyzing
            if (isAnalyzing && !hiddenWebViewUrl.isNullOrBlank()) {
                HiddenBackgroundWebView(
                    targetUrl = hiddenWebViewUrl,
                    onVideoDetected = { mp4Url, pageTitle, thumbnail ->
                        downloaderViewModel.onVideoDetected(mp4Url, pageTitle, thumbnail)
                    }
                )
            }
        }
    }
}

// -----------------------------------------------------------------------------
// 1. TOP INPUT SECTION
// -----------------------------------------------------------------------------
@Composable
fun TopInputSection(
    urlInput: String,
    isAnalyzing: Boolean,
    onUrlChange: (String) -> Unit,
    onPaste: () -> Unit,
    onGetVideo: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF1E293B)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Input Box with Paste Button
            OutlinedTextField(
                value = urlInput,
                onValueChange = onUrlChange,
                placeholder = {
                    Text(
                        text = "Paste video link here (Facebook, Instagram, Moj, Josh)",
                        fontSize = 12.5.sp,
                        color = Color.White.copy(alpha = 0.45f)
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Link,
                        contentDescription = "Link",
                        tint = Color(0xFF10B981)
                    )
                },
                trailingIcon = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(end = 4.dp)
                    ) {
                        if (urlInput.isNotEmpty()) {
                            IconButton(
                                onClick = { onUrlChange("") },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Clear",
                                    tint = Color.White.copy(alpha = 0.6f),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        // Paste Button
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFF334155),
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onPaste() }
                                .testTag("paste_button")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentPaste,
                                    contentDescription = "Paste",
                                    tint = Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Paste",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                },
                singleLine = true,
                maxLines = 1,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { onGetVideo() }),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF10B981),
                    unfocusedBorderColor = Color(0xFF334155),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedContainerColor = Color(0xFF0F172A),
                    unfocusedContainerColor = Color(0xFF0F172A)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("video_link_input")
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Big "Get Video" Button
            Button(
                onClick = onGetVideo,
                enabled = !isAnalyzing && urlInput.isNotBlank(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF2563EB), // Vibrant Royal Blue
                    disabledContainerColor = Color(0xFF1E293B).copy(alpha = 0.7f)
                ),
                contentPadding = PaddingValues(vertical = 14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("get_video_button")
            ) {
                if (isAnalyzing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.5.dp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Analyzing Video Link...",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Get Video",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------
// 2. MIDDLE: ANALYZING STATE CARD
// -----------------------------------------------------------------------------
@Composable
fun AnalyzingCard() {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            CircularProgressIndicator(
                color = Color(0xFF10B981),
                strokeWidth = 3.dp,
                modifier = Modifier.size(38.dp)
            )
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = "Connecting & Detecting Video Stream...",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Looking for MP4 video streams inside Facebook, Instagram, Moj, or Josh...",
                fontSize = 12.sp,
                color = Color.White.copy(alpha = 0.6f),
                textAlign = TextAlign.Center
            )
        }
    }
}

// -----------------------------------------------------------------------------
// 2. MIDDLE: VIDEO PREVIEW CARD (THUMBNAIL, TITLE, QUALITY + MB, LIVE SPEED)
// -----------------------------------------------------------------------------
@Composable
fun VideoPreviewCard(
    video: DetectedVideo,
    selectedQuality: String,
    activeDownload: DownloadedVideoItem?,
    onQualitySelected: (String) -> Unit,
    onDownloadNow: () -> Unit,
    onCancelDownload: (Long) -> Unit,
    onPlayDownloaded: (String) -> Unit
) {
    val selectedOption = video.qualities.find { it.label.equals(selectedQuality, ignoreCase = true) }
        ?: video.qualities.firstOrNull()

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF1E293B)
        ),
        border = androidx.compose.foundation.BorderStroke(1.2.dp, Color(0xFF10B981).copy(alpha = 0.5f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("video_preview_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header with badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFF10B981).copy(alpha = 0.2f)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF10B981))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "VIDEO READY FOR DOWNLOAD",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF10B981)
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFF334155)
                ) {
                    Text(
                        text = video.sourceDomain.uppercase(),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Video Preview + Title
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Thumbnail / Video Preview Box
                Box(
                    modifier = Modifier
                        .size(width = 104.dp, height = 78.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF0F172A)),
                    contentAlignment = Alignment.Center
                ) {
                    if (!video.thumbnail.isNullOrBlank()) {
                        AsyncImage(
                            model = ImageRequest.Builder(LocalContext.current)
                                .data(video.thumbnail)
                                .crossfade(true)
                                .build(),
                            contentDescription = "Video Thumbnail",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.PlayCircle,
                            contentDescription = null,
                            tint = Color(0xFF10B981),
                            modifier = Modifier.size(38.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Title and details
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = video.title,
                        fontSize = 14.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Format: MP4 Video • Fast Save",
                        fontSize = 12.sp,
                        color = Color(0xFF38BDF8)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = Color(0xFF334155).copy(alpha = 0.7f))
            Spacer(modifier = Modifier.height(14.dp))

            // Quality Options with clear MB sizes for each P!
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Choose Quality & Download Size (MB):",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Har resolution (P) ke mutabik MB dekhein aur select karein",
                        fontSize = 11.5.sp,
                        color = Color(0xFF94A3B8)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 2x2 Grid of Quality Cards displaying exact MB for each P!
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                val row1 = video.qualities.take(2)
                val row2 = video.qualities.drop(2).take(2)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    row1.forEach { q ->
                        QualityCard(
                            quality = q,
                            isSelected = selectedQuality.equals(q.label, ignoreCase = true),
                            onClick = { onQualitySelected(q.label) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                if (row2.isNotEmpty()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        row2.forEach { q ->
                            QualityCard(
                                quality = q,
                                isSelected = selectedQuality.equals(q.label, ignoreCase = true),
                                onClick = { onQualitySelected(q.label) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Informational Banner showing exactly how many MB this choice will use!
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFF0F172A),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.35f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = Color(0xFF38BDF8),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Selected: ${selectedOption?.label ?: selectedQuality} (${selectedOption?.resolution ?: ""}) • Requires ${selectedOption?.estimatedSize ?: ""} storage & data",
                        fontSize = 12.sp,
                        color = Color(0xFFE2E8F0),
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Live Animated Download Progress Card (if actively downloading in this card)
            if (activeDownload != null) {
                AnimatedDownloadProgressCard(
                    download = activeDownload,
                    onCancel = { activeDownload.downloadId?.let { onCancelDownload(it) } },
                    onPlay = onPlayDownloaded
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Big Vibrant "Download Now" Button with Selected Resolution & Estimated MB
            Button(
                onClick = onDownloadNow,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF10B981) // Vibrant Emerald
                ),
                contentPadding = PaddingValues(vertical = 15.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("card_download_now_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Download,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                val sizeText = selectedOption?.estimatedSize?.let { " ($it)" } ?: ""
                Text(
                    text = "Download $selectedQuality$sizeText",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}

/**
 * Animated network transmission bars (visual equalizer effect)
 */
@Composable
fun NetworkEqualizerBars(
    isActive: Boolean,
    tint: Color = Color(0xFF10B981),
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "equalizer")
    val phase1 by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(420, easing = LinearEasing), RepeatMode.Reverse),
        label = "eq1"
    )
    val phase2 by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(tween(340, easing = LinearEasing), RepeatMode.Reverse),
        label = "eq2"
    )
    val phase3 by infiniteTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(520, easing = LinearEasing), RepeatMode.Reverse),
        label = "eq3"
    )
    val phase4 by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(tween(380, easing = LinearEasing), RepeatMode.Reverse),
        label = "eq4"
    )

    Row(
        modifier = modifier.height(14.dp),
        horizontalArrangement = Arrangement.spacedBy(2.5.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        val h1 = if (isActive) phase1 else 0.3f
        val h2 = if (isActive) phase2 else 0.4f
        val h3 = if (isActive) phase3 else 0.5f
        val h4 = if (isActive) phase4 else 0.3f

        Box(Modifier.width(3.dp).fillMaxHeight(h1).clip(RoundedCornerShape(2.dp)).background(tint))
        Box(Modifier.width(3.dp).fillMaxHeight(h2).clip(RoundedCornerShape(2.dp)).background(tint))
        Box(Modifier.width(3.dp).fillMaxHeight(h3).clip(RoundedCornerShape(2.dp)).background(tint))
        Box(Modifier.width(3.dp).fillMaxHeight(h4).clip(RoundedCornerShape(2.dp)).background(tint))
    }
}

/**
 * Animated Glowing Progress Bar with smooth progress interpolation and moving light streak
 */
@Composable
fun AnimatedDownloadProgressBar(
    progressPercent: Int,
    modifier: Modifier = Modifier
) {
    val progressFraction = (progressPercent / 100f).coerceIn(0f, 1f)
    val animatedFraction by animateFloatAsState(
        targetValue = progressFraction,
        animationSpec = tween(durationMillis = 400, easing = FastOutSlowInEasing),
        label = "smooth_progress"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "shimmer_bar")
    val shimmerOffset by infiniteTransition.animateFloat(
        initialValue = -300f,
        targetValue = 900f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer_offset"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(12.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF1E293B))
    ) {
        // Filled bar with animated gradient
        if (animatedFraction > 0f) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(fraction = animatedFraction)
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                Color(0xFF0284C7), // Blue
                                Color(0xFF06B6D4), // Cyan
                                Color(0xFF10B981)  // Emerald
                            )
                        )
                    )
            )

            // Shimmer light sweep passing through the progress bar
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(fraction = animatedFraction)
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color.White.copy(alpha = 0.35f),
                                Color.Transparent
                            ),
                            start = androidx.compose.ui.geometry.Offset(shimmerOffset, 0f),
                            end = androidx.compose.ui.geometry.Offset(shimmerOffset + 180f, 0f)
                        )
                    )
            )
        }
    }
}

@Composable
fun QualityCard(
    quality: VideoQualityOption,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val borderColor = if (isSelected) Color(0xFF10B981) else Color(0xFF334155)
    val bgColor = if (isSelected) Color(0xFF10B981).copy(alpha = 0.16f) else Color(0xFF0F172A)

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = bgColor,
        border = androidx.compose.foundation.BorderStroke(if (isSelected) 2.dp else 1.dp, borderColor),
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = quality.label,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isSelected) Color(0xFF10B981) else Color.White
                    )
                    if (isSelected) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Selected",
                            tint = Color(0xFF10B981),
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(5.dp),
                    color = if (isSelected) Color(0xFF10B981).copy(alpha = 0.25f) else Color(0xFF1E293B)
                ) {
                    Text(
                        text = quality.badge,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isSelected) Color(0xFF10B981) else Color(0xFF94A3B8),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.5.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Prominently display MB size in a highlighted chip!
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = if (isSelected) Color(0xFF10B981).copy(alpha = 0.25f) else Color(0xFF0284C7).copy(alpha = 0.18f),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isSelected) Color(0xFF10B981).copy(alpha = 0.5f) else Color(0xFF38BDF8).copy(alpha = 0.35f)
                )
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = "⚡ ${quality.estimatedSize}",
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Black,
                        color = if (isSelected) Color(0xFF34D399) else Color(0xFF38BDF8)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = quality.resolution,
                fontSize = 10.5.sp,
                color = Color.White.copy(alpha = 0.65f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            if (quality.description.isNotBlank()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = quality.description,
                    fontSize = 9.5.sp,
                    color = Color(0xFF94A3B8),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun AnimatedDownloadProgressCard(
    download: DownloadedVideoItem,
    onCancel: () -> Unit,
    onPlay: (String) -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "download_shimmer")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    val isCompleted = download.status == DownloadStatus.COMPLETED

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF131D31)),
        border = androidx.compose.foundation.BorderStroke(
            1.2.dp,
            if (isCompleted) Color(0xFF10B981) else Color(0xFF06B6D4).copy(alpha = 0.6f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("animated_download_progress_card_${download.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Row 1: Status & Speedometer Pill with Live Equalizer Animation
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(
                                if (isCompleted) Color(0xFF10B981)
                                else Color(0xFF06B6D4).copy(alpha = pulseAlpha)
                            )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isCompleted) "Download Completed! ✅" else "Downloading ${download.qualityLabel} Video",
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                // Real-time Speed Meter Pill with animated Equalizer
                if (!isCompleted) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color(0xFF06B6D4).copy(alpha = 0.15f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF06B6D4).copy(alpha = 0.5f))
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                        ) {
                            NetworkEqualizerBars(
                                isActive = download.speedBytesPerSec > 0,
                                tint = Color(0xFF38BDF8)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "⚡ ${download.formattedSpeed}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF38BDF8)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Row 2: Live MB Counter, Percentage, and Time Remaining (ETA)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                // Downloaded MB block
                Column {
                    Text(
                        text = "DATA DOWNLOADED",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF94A3B8),
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = download.formattedProgressMb,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF38BDF8) // Vibrant Sky Blue
                    )
                }

                // ETA block
                if (!isCompleted) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "TIME REMAINING",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF94A3B8),
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = null,
                                tint = Color(0xFFFBBF24),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = download.formattedEta,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFBBF24)
                            )
                        }
                    }
                }

                // Large Progress Percentage
                Text(
                    text = "${download.progressPercent}%",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    color = if (isCompleted) Color(0xFF10B981) else Color(0xFF10B981)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Animated glowing progress bar with shimmer sweep
            AnimatedDownloadProgressBar(
                progressPercent = download.progressPercent,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Bottom action & directory info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Folder,
                        contentDescription = null,
                        tint = Color.White.copy(alpha = 0.5f),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "/Vidiopen/Downloads",
                        fontSize = 11.5.sp,
                        color = Color.White.copy(alpha = 0.55f)
                    )
                }

                if (!isCompleted) {
                    OutlinedButton(
                        onClick = onCancel,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = Color(0xFFEF4444)
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEF4444).copy(alpha = 0.5f)),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Cancel",
                            tint = Color(0xFFEF4444),
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Cancel",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            if (isCompleted) {
                Spacer(modifier = Modifier.height(14.dp))
                Button(
                    onClick = { onPlay(download.filePath) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(vertical = 13.dp),
                    modifier = Modifier.fillMaxWidth().testTag("play_downloaded_button_${download.id}")
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Play Video Now in Vidiopen",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.5.sp
                    )
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------
// 3. BOTTOM: DOWNLOADED VIDEOS LIST & EMPTY STATE
// -----------------------------------------------------------------------------
@Composable
fun EmptyDownloadsCard() {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Outlined.CloudDownload,
                contentDescription = null,
                tint = Color.White.copy(alpha = 0.4f),
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "No Downloaded Videos Yet",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Paste a link above from Facebook, Instagram, Moj, or Josh and click 'Get Video' to download.",
                fontSize = 12.sp,
                color = Color.White.copy(alpha = 0.55f),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun DownloadedVideoRow(
    item: DownloadedVideoItem,
    onPlay: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("downloaded_item_${item.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Video Thumbnail / Play Box
            Box(
                modifier = Modifier
                    .size(width = 72.dp, height = 54.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0F172A))
                    .clickable { onPlay() },
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data(File(item.filePath))
                        .crossfade(true)
                        .build(),
                    contentDescription = item.fileName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                // Play overlay
                Surface(
                    shape = CircleShape,
                    color = Color.Black.copy(alpha = 0.5f),
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Play",
                        tint = Color(0xFF10B981),
                        modifier = Modifier.padding(4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // File Name & Details
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onPlay() }
            ) {
                Text(
                    text = item.fileName.removeSuffix(".mp4"),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = item.formattedSize,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF10B981)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "•",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.4f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(item.dateDownloaded)),
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.45f)
                    )
                }
            }

            // Actions: Share & Delete
            IconButton(
                onClick = onShare,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = "Share",
                    tint = Color.White.copy(alpha = 0.7f),
                    modifier = Modifier.size(18.dp)
                )
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete",
                    tint = Color(0xFFEF4444).copy(alpha = 0.8f),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

// -----------------------------------------------------------------------------
// HIDDEN BACKGROUND WEBVIEW (SNIFFS MP4 / STREAMS FROM TARGET URL)
// -----------------------------------------------------------------------------
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun HiddenBackgroundWebView(
    targetUrl: String?,
    onVideoDetected: (url: String, title: String?, thumbnail: String?) -> Unit
) {
    var webViewInstance by remember { mutableStateOf<WebView?>(null) }
    var loadedTargetUrl by remember { mutableStateOf<String?>(null) }
    var cachedPageTitle by remember { mutableStateOf<String?>(null) }
    val mainHandler = remember { android.os.Handler(android.os.Looper.getMainLooper()) }

    DisposableEffect(Unit) {
        onDispose {
            try {
                webViewInstance?.stopLoading()
                webViewInstance?.onPause()
            } catch (_: Exception) {}
        }
    }

    // Keep hidden at 1dp size with alpha 0f
    Box(
        modifier = Modifier
            .size(1.dp)
            .alpha(0f)
    ) {
        AndroidView<WebView>(
            factory = { ctx ->
                // Ensure Chromium cache folders
                try {
                    val codeCacheDir = File(ctx.cacheDir, "WebView/Default/HTTP Cache/Code Cache")
                    File(codeCacheDir, "wasm").mkdirs()
                    File(codeCacheDir, "js").mkdirs()
                } catch (_: Exception) {}

                try {
                    WebView(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(1, 1)
                        // Disable hardware GPU acceleration to prevent MESA rendernode errors
                        setLayerType(android.view.View.LAYER_TYPE_SOFTWARE, null)

                        settings.apply {
                            javaScriptEnabled = true
                            domStorageEnabled = true
                            databaseEnabled = true
                            mediaPlaybackRequiresUserGesture = false
                            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                            userAgentString = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36"
                        }

                        // JavaScript Interface for DOM sniffing (executed on background JavaBridge thread)
                        addJavascriptInterface(
                            object {
                                @JavascriptInterface
                                fun onMediaFound(videoSrc: String, pageTitle: String?, thumbnail: String?) {
                                    if (videoSrc.isNotBlank()) {
                                        mainHandler.post {
                                            onVideoDetected(videoSrc, pageTitle ?: cachedPageTitle, thumbnail)
                                        }
                                    }
                                }
                            },
                            "VidiopenSniffer"
                        )

                        webChromeClient = object : WebChromeClient() {
                            override fun onReceivedTitle(view: WebView?, title: String?) {
                                super.onReceivedTitle(view, title)
                                if (!title.isNullOrBlank()) {
                                    cachedPageTitle = title
                                }
                            }
                        }

                        webViewClient = object : WebViewClient() {
                            // CRITICAL: Prevent host app process termination if Chromium renderer exits
                            override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                                timber.log.Timber.w("HiddenBackgroundWebView: render process exited gracefully")
                                try {
                                    view?.destroy()
                                } catch (_: Exception) {}
                                return true
                            }

                            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                                super.onReceivedError(view, request, error)
                            }

                            override fun onPageFinished(view: WebView?, url: String?) {
                                super.onPageFinished(view, url)
                                if (!view?.title.isNullOrBlank()) {
                                    cachedPageTitle = view?.title
                                }
                                // Inject HTML5 video & meta sniffer script safely
                                val js = """
                                    (function() {
                                        try {
                                            var title = document.title || '';
                                            var thumb = '';
                                            var ogImg = document.querySelector('meta[property="og:image"]');
                                            if (ogImg) thumb = ogImg.content;

                                            // Check og:video
                                            var ogVideo = document.querySelector('meta[property="og:video"]');
                                            if (ogVideo && ogVideo.content) {
                                                window.VidiopenSniffer.onMediaFound(ogVideo.content, title, thumb);
                                                return;
                                            }

                                            // Check video elements
                                            var videos = document.getElementsByTagName('video');
                                            for (var i = 0; i < videos.length; i++) {
                                                var v = videos[i];
                                                if (v.src && v.src.indexOf('blob:') !== 0) {
                                                    window.VidiopenSniffer.onMediaFound(v.src, title, thumb || v.poster);
                                                    return;
                                                }
                                                var sources = v.getElementsByTagName('source');
                                                for (var j = 0; j < sources.length; j++) {
                                                    if (sources[j].src && sources[j].src.indexOf('blob:') !== 0) {
                                                        window.VidiopenSniffer.onMediaFound(sources[j].src, title, thumb || v.poster);
                                                        return;
                                                    }
                                                }
                                            }
                                        } catch(e) {}
                                    })();
                                """.trimIndent()
                                view?.evaluateJavascript(js, null)
                            }

                            override fun onLoadResource(view: WebView?, url: String?) {
                                super.onLoadResource(view, url)
                                if (!url.isNullOrBlank()) {
                                    mainHandler.post {
                                        checkAndDispatchVideo(url, cachedPageTitle)
                                    }
                                }
                            }

                            override fun shouldInterceptRequest(
                                view: WebView?,
                                request: WebResourceRequest?
                            ): WebResourceResponse? {
                                val reqUrl = request?.url?.toString()
                                if (!reqUrl.isNullOrBlank()) {
                                    mainHandler.post {
                                        checkAndDispatchVideo(reqUrl, cachedPageTitle)
                                    }
                                }
                                return super.shouldInterceptRequest(view, request)
                            }

                            private fun checkAndDispatchVideo(url: String, pageTitle: String?) {
                                if (url.startsWith("blob:") || url.startsWith("data:")) return
                                if (url.contains("youtube.com") || url.contains("youtu.be") || url.contains("googlevideo.com")) return

                                val isMp4 = url.contains(".mp4", ignoreCase = true) ||
                                        url.contains(".webm", ignoreCase = true) ||
                                        url.contains("fbcdn.net", ignoreCase = true) && url.contains("video", ignoreCase = true) ||
                                        url.contains("cdninstagram.com", ignoreCase = true) && url.contains(".mp4", ignoreCase = true) ||
                                        url.contains("moj", ignoreCase = true) && url.contains(".mp4", ignoreCase = true) ||
                                        url.contains("josh", ignoreCase = true) && url.contains(".mp4", ignoreCase = true)

                                if (isMp4) {
                                    onVideoDetected(url, pageTitle, null)
                                }
                            }
                        }

                        webViewInstance = this
                    }
                } catch (e: Exception) {
                    timber.log.Timber.e(e, "Could not initialize WebView")
                    WebView(ctx).apply {
                        setLayerType(android.view.View.LAYER_TYPE_SOFTWARE, null)
                    }
                }
            },
            update = { webView ->
                if (!targetUrl.isNullOrBlank() && targetUrl != loadedTargetUrl) {
                    loadedTargetUrl = targetUrl
                    webView.loadUrl(targetUrl)
                }
            },
            onRelease = { webView ->
                try {
                    webView.stopLoading()
                    webView.onPause()
                } catch (_: Exception) {}
            }
        )
    }
}
