package com.example.downloader.model

data class VideoQualityOption(
    val label: String,
    val resolution: String,
    val estimatedSize: String = "",
    val sizeBytes: Long = 0L,
    val badge: String = "HD",
    val description: String = "",
    val videoUrl: String
)

data class DetectedVideo(
    val url: String,
    val title: String,
    val sourceDomain: String,
    val mimeType: String = "video/mp4",
    val thumbnail: String? = null,
    val detectedAt: Long = System.currentTimeMillis(),
    val qualities: List<VideoQualityOption> = listOf(
        VideoQualityOption(
            label = "1080p",
            resolution = "Full HD (1080p)",
            estimatedSize = "~38.4 MB",
            sizeBytes = 38_400_000L,
            badge = "BEST",
            description = "Crisp Full HD • Best Quality",
            videoUrl = url
        ),
        VideoQualityOption(
            label = "720p",
            resolution = "High Definition (720p)",
            estimatedSize = "~18.2 MB",
            sizeBytes = 18_200_000L,
            badge = "RECOMMENDED",
            description = "Great balance of clarity & speed",
            videoUrl = url
        ),
        VideoQualityOption(
            label = "480p",
            resolution = "Standard Quality (480p)",
            estimatedSize = "~9.5 MB",
            sizeBytes = 9_500_000L,
            badge = "FAST",
            description = "Quick download • Saves 50% data",
            videoUrl = url
        ),
        VideoQualityOption(
            label = "360p",
            resolution = "Data Saver (360p)",
            estimatedSize = "~4.8 MB",
            sizeBytes = 4_800_000L,
            badge = "SUPER SAVER",
            description = "Smallest size • Saves 75% data",
            videoUrl = url
        )
    )
)
