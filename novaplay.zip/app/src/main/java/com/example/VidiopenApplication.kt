package com.example

import android.app.ActivityManager
import android.app.Application
import android.content.Context
import coil.Coil
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import com.example.di.AppContainer
import com.example.di.AppContainerImpl
import timber.log.Timber

class VidiopenApplication : Application(), ImageLoaderFactory {
    lateinit var container: AppContainer

    override fun onCreate() {
        super.onCreate()
        container = AppContainerImpl(this)
        
        // Initialize Timber logging
        Timber.plant(Timber.DebugTree())
        Timber.d("VidiopenApplication: Initialized successfully with manual DI and Timber")

        // Pre-create WebView cache directories so Chromium's simple_file_enumerator doesn't fail
        try {
            val webViewCacheDir = java.io.File(cacheDir, "WebView/Default/HTTP Cache/Code Cache")
            java.io.File(webViewCacheDir, "wasm").mkdirs()
            java.io.File(webViewCacheDir, "js").mkdirs()
            java.io.File(cacheDir, "WebView/Default/HTTP Cache/index-dir").mkdirs()
        } catch (_: Exception) {}

        // Cleanup any leftover decrypted files from prior crashes
        try {
            val playDir = java.io.File(cacheDir, "temp_vault_play")
            if (playDir.exists()) {
                playDir.listFiles()?.forEach { it.delete() }
            }
        } catch (_: Exception) {}
    }

    override fun newImageLoader(): ImageLoader {
        val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val isLowRam = activityManager?.isLowRamDevice ?: false

        return ImageLoader.Builder(this)
            .components {
                add(com.example.utils.VideoThumbnailFetcher.Factory(this@VidiopenApplication))
                add(VideoFrameDecoder.Factory())
            }
            .memoryCache {
                coil.memory.MemoryCache.Builder(this)
                    .maxSizePercent(if (isLowRam) 0.12 else 0.18)
                    .build()
            }
            .diskCache {
                coil.disk.DiskCache.Builder()
                    .directory(cacheDir.resolve("image_cache"))
                    .maxSizeBytes(if (isLowRam) 50L * 1024L * 1024L else 120L * 1024L * 1024L)
                    .build()
            }
            .bitmapConfig(android.graphics.Bitmap.Config.RGB_565)
            .allowRgb565(true)
            .crossfade(true)
            .build()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
            try {
                Coil.imageLoader(this).memoryCache?.clear()
                com.example.utils.VideoThumbnailMemoryCache.clear()
            } catch (e: Exception) {
                // Ignore
            }
        }
    }

    override fun onLowMemory() {
        super.onLowMemory()
        try {
            Coil.imageLoader(this).memoryCache?.clear()
            com.example.utils.VideoThumbnailMemoryCache.clear()
        } catch (e: Exception) {
            // Ignore
        }
    }
}
