package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun rememberPlaybackTime(isPlaying: Boolean, speed: Float = 1.0f): State<Float> {
    val animTime = remember { mutableStateOf(0f) }
    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            var lastTime = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                val dt = ((now - lastTime) / 1_000_000_000f) * speed
                lastTime = now
                animTime.value += dt
            }
        }
    }
    return animTime
}

@Composable
fun AestheticThemeBackground(
    themeId: String,
    isPlaying: Boolean,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize()) {
        when (themeId) {
            // 5 User-Requested Distinct Music Player Themes:
            "cinematic" -> CinematicThemeView(isPlaying = isPlaying)
            "music_feel" -> MusicFeelThemeView(isPlaying = isPlaying)
            "nature" -> NatureThemeView(isPlaying = isPlaying)
            "night" -> NightThemeView(isPlaying = isPlaying)
            "night_cinematic_moon" -> NightCinematicMoonThemeView(isPlaying = isPlaying)

            // Existing themes
            "cyber_neon_feel" -> CyberNeonFeelThemeView(isPlaying = isPlaying)
            "moonlight_night" -> MoonlightNightThemeView(isPlaying = isPlaying)
            "foggy_city" -> FoggyCityThemeView(isPlaying = isPlaying)
            "glowing_notes" -> GlowingNotesThemeView(isPlaying = isPlaying)
            "headphones_wave" -> HeadphonesWaveThemeView(isPlaying = isPlaying)
            "dark_collage" -> DarkCollageThemeView(isPlaying = isPlaying)
            else -> CinematicThemeView(isPlaying = isPlaying)
        }
    }
}

// ==================================================================================================
// THEME 1: Cinematic (Widescreen Letterbox, Projector God-Rays, Anamorphic Flares & Golden Embers)
// ==================================================================================================
@Composable
fun CinematicThemeView(isPlaying: Boolean) {
    val time by rememberPlaybackTime(isPlaying, speed = 1.0f)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0C0804))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // 1. Deep Cinema Widescreen background gradient
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF070402),
                        Color(0xFF160E06),
                        Color(0xFF221509),
                        Color(0xFF130C05),
                        Color(0xFF070402)
                    )
                )
            )

            // 2. Projector God-Ray / Spotlight from top center
            val beamBreath = 0.07f + 0.03f * sin(time * 1.5f)
            val beamPath = Path().apply {
                moveTo(w * 0.5f, 0f)
                lineTo(w * 0.92f, h)
                lineTo(w * 0.08f, h)
                close()
            }
            drawPath(
                path = beamPath,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFFFFF7ED).copy(alpha = beamBreath * 1.8f),
                        Color(0xFFF59E0B).copy(alpha = beamBreath),
                        Color.Transparent
                    )
                )
            )

            // 3. Horizontal Anamorphic Lens Flare
            val flareY = h * 0.40f
            val flarePulse = 0.6f + 0.4f * sin(time * 2f)
            drawRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        Color.Transparent,
                        Color(0xFFD97706).copy(alpha = 0.25f * flarePulse),
                        Color(0xFFFFB800).copy(alpha = 0.70f * flarePulse),
                        Color(0xFFFFFBEB).copy(alpha = 0.95f * flarePulse),
                        Color(0xFFFFB800).copy(alpha = 0.70f * flarePulse),
                        Color(0xFFD97706).copy(alpha = 0.25f * flarePulse),
                        Color.Transparent
                    )
                ),
                topLeft = Offset(0f, flareY - 3.dp.toPx()),
                size = Size(w, 6.dp.toPx())
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFFFFFBEB).copy(alpha = 0.85f * flarePulse),
                        Color(0xFFFFB800).copy(alpha = 0.45f * flarePulse),
                        Color(0xFFD97706).copy(alpha = 0.15f * flarePulse),
                        Color.Transparent
                    ),
                    center = Offset(w * 0.5f, flareY),
                    radius = w * 0.42f
                ),
                center = Offset(w * 0.5f, flareY),
                radius = w * 0.42f
            )

            // 4. Floating Cinematic Film Embers / Bokeh Dust Particles
            val emberCount = 24
            for (i in 0 until emberCount) {
                val seed = i * 137.5f
                val initialX = (seed * 9.3f) % w
                val initialY = (seed * 17.7f) % h
                val speed = 25.dp.toPx() + (i % 5) * 12.dp.toPx()
                val phase = seed * 0.05f

                val curY = ((initialY - time * speed) % h + h) % h
                val curX = (initialX + sin(time * 1.4f + phase) * 25.dp.toPx() + w) % w
                val alpha = (0.25f + 0.65f * abs(sin(time * 2f + phase))).coerceIn(0.1f, 1f)
                val radius = (1.5f + (i % 4) * 1.2f).dp.toPx()

                drawCircle(
                    color = Color(0xFFFFB800).copy(alpha = alpha * 0.45f),
                    radius = radius * 2.5f,
                    center = Offset(curX, curY)
                )
                drawCircle(
                    color = Color(0xFFFFFBEB).copy(alpha = alpha),
                    radius = radius,
                    center = Offset(curX, curY)
                )
            }

            // 5. Cinema Framing Letterbox hairline gold accents
            drawLine(
                brush = Brush.horizontalGradient(
                    listOf(Color.Transparent, Color(0xFFFFB800).copy(alpha = 0.6f), Color.Transparent)
                ),
                start = Offset(w * 0.1f, 40.dp.toPx()),
                end = Offset(w * 0.9f, 40.dp.toPx()),
                strokeWidth = 1.5.dp.toPx()
            )
            drawLine(
                brush = Brush.horizontalGradient(
                    listOf(Color.Transparent, Color(0xFFFFB800).copy(alpha = 0.6f), Color.Transparent)
                ),
                start = Offset(w * 0.1f, h - 80.dp.toPx()),
                end = Offset(w * 0.9f, h - 80.dp.toPx()),
                strokeWidth = 1.5.dp.toPx()
            )
        }
    }
}

// ==================================================================================================
// THEME 2: Music Feel (Rhythmic Expanding Waves, Chroma Spectrum Equalizer & Floating Notes)
// ==================================================================================================
@Composable
fun MusicFeelThemeView(isPlaying: Boolean) {
    val time by rememberPlaybackTime(isPlaying, speed = 1.2f)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF080114))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val centerX = w * 0.5f
            val centerY = h * 0.40f

            // 1. Cyber Dark background gradient
            drawRect(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF1E0438),
                        Color(0xFF100222),
                        Color(0xFF06000E)
                    ),
                    center = Offset(centerX, centerY),
                    radius = w * 0.9f
                )
            )

            // 2. Expanding Concentric Audio Waves
            val maxWaveRadius = w * 0.7f
            val waveCount = 4
            for (i in 0 until waveCount) {
                val progress = ((time * 0.22f + i * 0.25f) % 1f)
                val waveRadius = progress * maxWaveRadius
                val waveAlpha = ((1f - progress) * 0.75f).coerceIn(0f, 1f)
                val waveColor = if (i % 2 == 0) Color(0xFF00F0FF) else Color(0xFFFF007F)

                drawCircle(
                    color = waveColor.copy(alpha = waveAlpha),
                    radius = waveRadius,
                    center = Offset(centerX, centerY),
                    style = Stroke(width = (2.5f - progress * 1.5f).dp.toPx())
                )
            }

            // 3. Central Pulsing Bass Aura
            val bassPulse = 1f + 0.16f * abs(sin(time * 4.5f))
            val baseRadius = 55.dp.toPx() * bassPulse
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF00F0FF).copy(alpha = 0.55f),
                        Color(0xFFFF007F).copy(alpha = 0.25f),
                        Color.Transparent
                    ),
                    center = Offset(centerX, centerY),
                    radius = baseRadius * 2.2f
                ),
                radius = baseRadius * 2.2f,
                center = Offset(centerX, centerY)
            )

            // 4. Dynamic Equalizer Spectrum Bars at bottom
            val barCount = 22
            val barMargin = w * 0.06f
            val availableWidth = w - (barMargin * 2)
            val barSpacing = availableWidth / barCount
            val barWidth = barSpacing * 0.65f
            val baseBarY = h * 0.88f

            for (i in 0 until barCount) {
                val barX = barMargin + i * barSpacing
                val waveVal = abs(sin(time * 5f + i * 0.45f) * cos(time * 2.5f + i * 0.7f))
                val barHeight = (15.dp.toPx() + waveVal * 75.dp.toPx())

                drawRoundRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF00F0FF),
                            Color(0xFFFF007F)
                        ),
                        startY = baseBarY - barHeight,
                        endY = baseBarY
                    ),
                    topLeft = Offset(barX, baseBarY - barHeight),
                    size = Size(barWidth, barHeight),
                    cornerRadius = CornerRadius(barWidth / 2, barWidth / 2)
                )

                drawCircle(
                    color = Color.White.copy(alpha = 0.9f),
                    radius = barWidth * 0.4f,
                    center = Offset(barX + barWidth / 2, baseBarY - barHeight)
                )
            }

            // 5. Floating Musical Notes
            val noteCount = 8
            for (i in 0 until noteCount) {
                val seed = i * 113.3f
                val noteSpeed = 30.dp.toPx() + (i % 4) * 10.dp.toPx()
                val initialY = (seed * 11.7f) % (h * 0.7f) + h * 0.15f
                val initialX = (seed * 7.1f) % (w * 0.8f) + w * 0.1f
                val phase = seed * 0.07f

                val noteY = ((initialY - time * noteSpeed) % (h * 0.75f) + h * 0.75f) % (h * 0.75f)
                val noteX = initialX + sin(time * 1.6f + phase) * 24.dp.toPx()
                val noteAlpha = (0.35f + 0.60f * abs(sin(time * 2.2f + phase))).coerceIn(0.15f, 1f)
                val noteColor = if (i % 2 == 0) Color(0xFF00F0FF) else Color(0xFFFF007F)

                val headRadius = 4.5.dp.toPx()
                drawOval(
                    color = noteColor.copy(alpha = noteAlpha),
                    topLeft = Offset(noteX, noteY),
                    size = Size(headRadius * 2.2f, headRadius * 1.6f)
                )
                val stemX = noteX + headRadius * 2.1f
                drawLine(
                    color = noteColor.copy(alpha = noteAlpha),
                    start = Offset(stemX, noteY + headRadius * 0.8f),
                    end = Offset(stemX, noteY - 14.dp.toPx()),
                    strokeWidth = 2.dp.toPx(),
                    cap = StrokeCap.Round
                )
                drawLine(
                    color = noteColor.copy(alpha = noteAlpha),
                    start = Offset(stemX, noteY - 14.dp.toPx()),
                    end = Offset(stemX + 6.dp.toPx(), noteY - 9.dp.toPx()),
                    strokeWidth = 2.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }
        }
    }
}

// ==================================================================================================
// THEME 3: Nature (Enchanted Forest, Twilight Canopy, Glowing Fireflies & Drifting Leaves)
// ==================================================================================================
@Composable
fun NatureThemeView(isPlaying: Boolean) {
    val time by rememberPlaybackTime(isPlaying, speed = 1.0f)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF02120A))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // 1. Deep Enchanted Forest Night gradient
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF010E07),
                        Color(0xFF042013),
                        Color(0xFF08321F),
                        Color(0xFF041E12),
                        Color(0xFF010B05)
                    )
                )
            )

            // 2. Sunlight / Moonbeam God-Rays from top left
            val rayShift = sin(time * 0.8f) * 20.dp.toPx()
            val rayPath1 = Path().apply {
                moveTo(w * 0.1f + rayShift, 0f)
                lineTo(w * 0.65f + rayShift, h)
                lineTo(w * 0.45f + rayShift, h)
                lineTo(w * 0.0f + rayShift, 0f)
                close()
            }
            drawPath(
                path = rayPath1,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF76FF03).copy(alpha = 0.08f),
                        Color(0xFF00E676).copy(alpha = 0.04f),
                        Color.Transparent
                    ),
                    start = Offset(w * 0.1f, 0f),
                    end = Offset(w * 0.6f, h)
                )
            )

            // 3. Glowing Fireflies with organic orbital motion
            val fireflyCount = 18
            for (i in 0 until fireflyCount) {
                val seed = i * 97.3f
                val baseX = (seed * 8.7f) % (w * 0.85f) + w * 0.07f
                val baseY = (seed * 13.9f) % (h * 0.75f) + h * 0.12f
                val speedX = 0.8f + (i % 3) * 0.4f
                val speedY = 0.7f + ((i + 1) % 3) * 0.35f
                val phase = seed * 0.08f

                val fx = baseX + cos(time * speedX + phase) * 35.dp.toPx() + sin(time * 0.4f) * 12.dp.toPx()
                val fy = baseY + sin(time * speedY + phase) * 28.dp.toPx() + cos(time * 0.5f) * 10.dp.toPx()
                val glowAlpha = (0.20f + 0.80f * abs(sin(time * 2.2f + phase))).coerceIn(0f, 1f)

                drawCircle(
                    color = Color(0xFF00E676).copy(alpha = glowAlpha * 0.35f),
                    radius = 16.dp.toPx(),
                    center = Offset(fx, fy)
                )
                drawCircle(
                    color = Color(0xFF76FF03).copy(alpha = glowAlpha * 0.70f),
                    radius = 6.dp.toPx(),
                    center = Offset(fx, fy)
                )
                drawCircle(
                    color = Color(0xFFFFF9C4).copy(alpha = glowAlpha),
                    radius = 2.dp.toPx(),
                    center = Offset(fx, fy)
                )
            }

            // 4. Drifting Forest Leaves fluttering down
            val leafCount = 7
            for (i in 0 until leafCount) {
                val seed = i * 143.5f
                val fallSpeed = 30.dp.toPx() + (i % 3) * 12.dp.toPx()
                val initialY = (seed * 19.3f) % h
                val initialX = (seed * 11.1f) % (w * 0.85f) + w * 0.07f
                val phase = seed * 0.1f

                val curY = ((initialY + time * fallSpeed) % h + h) % h
                val curX = (initialX + sin(time * 1.5f + phase) * 35.dp.toPx() + w) % w
                val leafAlpha = 0.55f + 0.35f * sin(time * 1.8f + phase)

                val leafSize = (14 + (i % 3) * 5).dp.toPx()
                drawOval(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF76FF03).copy(alpha = leafAlpha),
                            Color(0xFF00C853).copy(alpha = leafAlpha * 0.7f)
                        )
                    ),
                    topLeft = Offset(curX - leafSize * 0.5f, curY - leafSize * 0.25f),
                    size = Size(leafSize, leafSize * 0.5f)
                )
            }

            // 5. Silhouetted Forest Grass/Blades at the bottom
            val grassPath = Path().apply {
                moveTo(0f, h)
                var gx = 0f
                val step = w / 20f
                var i = 0
                while (gx <= w) {
                    val sway = sin(time * 1.5f + i * 0.4f) * 6.dp.toPx()
                    val bladeHeight = 22.dp.toPx() + ((i % 4) * 8).dp.toPx()
                    lineTo(gx + step * 0.5f + sway, h - bladeHeight)
                    lineTo(gx + step, h)
                    gx += step
                    i++
                }
                lineTo(w, h)
                close()
            }
            drawPath(
                path = grassPath,
                color = Color(0xFF010A05).copy(alpha = 0.85f)
            )
        }
    }
}

// ==================================================================================================
// THEME 4: Night (Deep Midnight Sky, Twinkling Constellations, Cosmic Dust & Shooting Stars)
// ==================================================================================================
@Composable
fun NightThemeView(isPlaying: Boolean) {
    val time by rememberPlaybackTime(isPlaying, speed = 1.0f)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF030712))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // 1. Deep Midnight Blue to Obsidian gradient
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF02040A),
                        Color(0xFF060E22),
                        Color(0xFF0C1938),
                        Color(0xFF060E22),
                        Color(0xFF02040B)
                    )
                )
            )

            // 2. Cosmic Nebula Cloud Drift
            val nebulaBreath = 0.18f + 0.08f * sin(time * 0.7f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF38BDF8).copy(alpha = nebulaBreath),
                        Color(0xFF6366F1).copy(alpha = nebulaBreath * 0.6f),
                        Color.Transparent
                    ),
                    center = Offset(w * 0.75f, h * 0.35f),
                    radius = w * 0.65f
                ),
                center = Offset(w * 0.75f, h * 0.35f),
                radius = w * 0.65f
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF818CF8).copy(alpha = nebulaBreath * 0.7f),
                        Color(0xFF1E1B4B).copy(alpha = nebulaBreath * 0.3f),
                        Color.Transparent
                    ),
                    center = Offset(w * 0.25f, h * 0.65f),
                    radius = w * 0.55f
                ),
                center = Offset(w * 0.25f, h * 0.65f),
                radius = w * 0.55f
            )

            // 3. Twinkling Starfield with Constellation Stars
            val starCount = 38
            for (i in 0 until starCount) {
                val seed = i * 123.7f
                val sx = (seed * 13.3f) % (w * 0.92f) + w * 0.04f
                val sy = (seed * 21.1f) % (h * 0.88f) + h * 0.05f
                val twinkleSpeed = 1.2f + (i % 4) * 0.8f
                val phase = seed * 0.12f

                val alpha = (0.2f + 0.8f * (0.5f + 0.5f * sin(time * twinkleSpeed + phase))).coerceIn(0.1f, 1f)
                val starRadius = (1.2f + (i % 3) * 0.9f).dp.toPx()

                drawCircle(
                    color = Color.White.copy(alpha = alpha),
                    radius = starRadius,
                    center = Offset(sx, sy)
                )

                if (i % 6 == 0) {
                    val crossLen = (starRadius * 3.5f)
                    drawLine(
                        color = Color(0xFFBAE6FD).copy(alpha = alpha * 0.8f),
                        start = Offset(sx - crossLen, sy),
                        end = Offset(sx + crossLen, sy),
                        strokeWidth = 1.dp.toPx()
                    )
                    drawLine(
                        color = Color(0xFFBAE6FD).copy(alpha = alpha * 0.8f),
                        start = Offset(sx, sy - crossLen),
                        end = Offset(sx, sy + crossLen),
                        strokeWidth = 1.dp.toPx()
                    )
                }
            }

            // 4. Constellation Lines connecting key stars
            val const1A = Offset(w * 0.22f, h * 0.22f)
            val const1B = Offset(w * 0.38f, h * 0.18f)
            val const1C = Offset(w * 0.48f, h * 0.28f)
            val constAlpha = 0.25f + 0.15f * sin(time * 1.1f)
            drawLine(Color(0xFF38BDF8).copy(alpha = constAlpha), const1A, const1B, strokeWidth = 1.dp.toPx())
            drawLine(Color(0xFF38BDF8).copy(alpha = constAlpha), const1B, const1C, strokeWidth = 1.dp.toPx())

            // 5. Periodic Shooting Star (Meteor Streak)
            val meteorPeriod = 5.0f
            val cycle = (time % meteorPeriod)
            if (cycle < 1.1f) {
                val progress = cycle / 1.1f
                val startX = w * 0.9f - progress * (w * 0.7f)
                val startY = h * 0.12f + progress * (h * 0.35f)
                val tailLen = 65.dp.toPx()
                val tailX = startX + tailLen * 0.85f
                val tailY = startY - tailLen * 0.52f
                val meteorAlpha = (1f - progress).coerceIn(0f, 1f)

                drawLine(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color.White.copy(alpha = meteorAlpha),
                            Color(0xFF38BDF8).copy(alpha = meteorAlpha * 0.6f),
                            Color.Transparent
                        ),
                        start = Offset(startX, startY),
                        end = Offset(tailX, tailY)
                    ),
                    start = Offset(startX, startY),
                    end = Offset(tailX, tailY),
                    strokeWidth = 2.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }
        }
    }
}

// ==================================================================================================
// THEME 5: Night or Cinematic or Moon ek sath (Luminous Moon, Anamorphic Flares, Night Sky & Drifting Clouds)
// ==================================================================================================
@Composable
fun NightCinematicMoonThemeView(isPlaying: Boolean) {
    val time by rememberPlaybackTime(isPlaying, speed = 1.0f)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF030612))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // 1. Deep Celestial Midnight Gradient
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF020511),
                        Color(0xFF071126),
                        Color(0xFF0C1D3F),
                        Color(0xFF071025),
                        Color(0xFF020510)
                    )
                )
            )

            // 2. Night Stars in background
            val starCount = 28
            for (i in 0 until starCount) {
                val seed = i * 109.1f
                val sx = (seed * 11.9f) % (w * 0.92f) + w * 0.04f
                val sy = (seed * 19.7f) % (h * 0.85f) + h * 0.05f
                val twinkleSpeed = 1.5f + (i % 3) * 0.7f
                val phase = seed * 0.09f
                val alpha = (0.2f + 0.8f * (0.5f + 0.5f * sin(time * twinkleSpeed + phase))).coerceIn(0.1f, 1f)

                drawCircle(
                    color = Color.White.copy(alpha = alpha),
                    radius = (1.2f + (i % 3) * 0.8f).dp.toPx(),
                    center = Offset(sx, sy)
                )
            }

            // 3. GLOWING FULL MOON (Centerpiece)
            val moonCenter = Offset(w * 0.5f, h * 0.30f)
            val moonRadius = 48.dp.toPx()

            // A. Outer Pulsing Lunar Halo (Aura breathes with playback)
            val haloPulse = 1f + 0.08f * sin(time * 2f)
            val outerRadius = moonRadius * 3.4f * haloPulse
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFFFFFBEB).copy(alpha = 0.55f),
                        Color(0xFFFDE68A).copy(alpha = 0.25f),
                        Color(0xFF93C5FD).copy(alpha = 0.10f),
                        Color.Transparent
                    ),
                    center = moonCenter,
                    radius = outerRadius
                ),
                center = moonCenter,
                radius = outerRadius
            )

            // B. Inner Soft Pearl Corona
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.90f),
                        Color(0xFFFFF8E7).copy(alpha = 0.50f),
                        Color.Transparent
                    ),
                    center = moonCenter,
                    radius = moonRadius * 1.5f
                ),
                center = moonCenter,
                radius = moonRadius * 1.5f
            )

            // C. Moon Disc Surface
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFFFFFFFF),
                        Color(0xFFFFFDF2),
                        Color(0xFFF1F5F9),
                        Color(0xFFE2E8F0)
                    ),
                    center = Offset(moonCenter.x - moonRadius * 0.25f, moonCenter.y - moonRadius * 0.25f),
                    radius = moonRadius
                ),
                radius = moonRadius,
                center = moonCenter
            )

            // D. Lunar Maria / Craters (Authentic topography shading)
            val craterColor = Color(0xFFCBD5E1).copy(alpha = 0.55f)
            drawOval(
                color = craterColor,
                topLeft = Offset(moonCenter.x - moonRadius * 0.65f, moonCenter.y - moonRadius * 0.35f),
                size = Size(moonRadius * 0.7f, moonRadius * 0.5f)
            )
            drawOval(
                color = craterColor,
                topLeft = Offset(moonCenter.x + moonRadius * 0.1f, moonCenter.y - moonRadius * 0.5f),
                size = Size(moonRadius * 0.5f, moonRadius * 0.4f)
            )
            drawOval(
                color = craterColor,
                topLeft = Offset(moonCenter.x - moonRadius * 0.2f, moonCenter.y + moonRadius * 0.1f),
                size = Size(moonRadius * 0.65f, moonRadius * 0.45f)
            )

            // 4. CINEMATIC ANAMORPHIC LENS FLARE across the Moon
            val flarePulse = 0.65f + 0.35f * sin(time * 1.8f)
            drawRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        Color.Transparent,
                        Color(0xFF38BDF8).copy(alpha = 0.20f * flarePulse),
                        Color(0xFFFDE68A).copy(alpha = 0.65f * flarePulse),
                        Color.White.copy(alpha = 0.90f * flarePulse),
                        Color(0xFFFDE68A).copy(alpha = 0.65f * flarePulse),
                        Color(0xFF38BDF8).copy(alpha = 0.20f * flarePulse),
                        Color.Transparent
                    )
                ),
                topLeft = Offset(0f, moonCenter.y - 2.5.dp.toPx()),
                size = Size(w, 5.dp.toPx())
            )

            // 5. CINEMATIC NIGHT CLOUDS drifting across the Moon
            val cloud1Speed = 16.dp.toPx()
            val cloud1X = ((time * cloud1Speed + w * 0.15f) % (w + 260.dp.toPx())) - 130.dp.toPx()
            val cloud1Y = moonCenter.y + moonRadius * 0.15f
            drawOval(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF1E293B).copy(alpha = 0.60f),
                        Color(0xFF0F172A).copy(alpha = 0.35f),
                        Color.Transparent
                    ),
                    center = Offset(cloud1X + 80.dp.toPx(), cloud1Y),
                    radius = 90.dp.toPx()
                ),
                topLeft = Offset(cloud1X, cloud1Y - 22.dp.toPx()),
                size = Size(170.dp.toPx(), 44.dp.toPx())
            )

            val cloud2Speed = 10.dp.toPx()
            val cloud2X = ((time * cloud2Speed + w * 0.6f) % (w + 320.dp.toPx())) - 160.dp.toPx()
            val cloud2Y = moonCenter.y - moonRadius * 0.3f
            drawOval(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF1E293B).copy(alpha = 0.50f),
                        Color(0xFF0F172A).copy(alpha = 0.25f),
                        Color.Transparent
                    ),
                    center = Offset(cloud2X + 90.dp.toPx(), cloud2Y),
                    radius = 100.dp.toPx()
                ),
                topLeft = Offset(cloud2X, cloud2Y - 18.dp.toPx()),
                size = Size(190.dp.toPx(), 38.dp.toPx())
            )

            // 6. Cinematic Vignette Letterbox Accent lines
            drawLine(
                brush = Brush.horizontalGradient(
                    listOf(Color.Transparent, Color(0xFFFDE68A).copy(alpha = 0.5f), Color.Transparent)
                ),
                start = Offset(w * 0.15f, 35.dp.toPx()),
                end = Offset(w * 0.85f, 35.dp.toPx()),
                strokeWidth = 1.2.dp.toPx()
            )
            drawLine(
                brush = Brush.horizontalGradient(
                    listOf(Color.Transparent, Color(0xFFFDE68A).copy(alpha = 0.5f), Color.Transparent)
                ),
                start = Offset(w * 0.15f, h - 85.dp.toPx()),
                end = Offset(w * 0.85f, h - 85.dp.toPx()),
                strokeWidth = 1.2.dp.toPx()
            )
        }
    }
}

// --------------------------------------------------------------------------------------------------
// THEME 1: Moonlight Night (Full Moon + Silhouetted Branches + Frame Box + Heart)
// --------------------------------------------------------------------------------------------------
@Composable
fun MoonlightNightThemeView(isPlaying: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "MoonlightAnim")
    
    // Moon pulse animation
    val moonPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "MoonPulse"
    )

    // Star twinkle phase
    val starPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28318f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "StarPhase"
    )

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF070A12))) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // 1. Dark night gradient background
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF050811),
                        Color(0xFF0D1322),
                        Color(0xFF080C16)
                    )
                )
            )

            // 2. Twinkling stars
            val starPositions = listOf(
                Offset(w * 0.15f, h * 0.12f), Offset(w * 0.82f, h * 0.18f),
                Offset(w * 0.25f, h * 0.28f), Offset(w * 0.75f, h * 0.35f),
                Offset(w * 0.10f, h * 0.55f), Offset(w * 0.88f, h * 0.62f),
                Offset(w * 0.20f, h * 0.78f), Offset(w * 0.80f, h * 0.85f)
            )
            starPositions.forEachIndexed { i, pos ->
                val alpha = (0.3f + 0.5f * sin(starPhase + i * 1.2f)).coerceIn(0.1f, 1f)
                drawCircle(color = Color.White.copy(alpha = alpha), radius = 2f, center = pos)
            }

            // 3. Glowing Full Moon
            val moonCenter = Offset(w * 0.52f, h * 0.32f)
            val moonRadius = 24.dp.toPx() * moonPulse

            // Radial Glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.85f),
                        Color(0xFFFFF8E7).copy(alpha = 0.35f),
                        Color(0xFFE2E8F0).copy(alpha = 0.10f),
                        Color.Transparent
                    ),
                    center = moonCenter,
                    radius = moonRadius * 3.5f
                ),
                radius = moonRadius * 3.5f,
                center = moonCenter
            )

            // Moon disc
            drawCircle(
                color = Color(0xFFFFFFF0),
                radius = moonRadius,
                center = moonCenter
            )

            // 4. White rectangular frame outline in center (Matching Image 1)
            val frameMargin = w * 0.12f
            val frameTop = h * 0.16f
            val frameSize = w - (frameMargin * 2)
            val frameRect = Rect(frameMargin, frameTop, frameMargin + frameSize, frameTop + frameSize)

            drawRect(
                color = Color.White,
                topLeft = Offset(frameRect.left, frameRect.top),
                size = Size(frameRect.width, frameRect.height),
                style = Stroke(width = 3.dp.toPx())
            )

            // 5. Silhouetted Tree Branches & Leaves across screen
            val branchPath = Path().apply {
                // Main diagonal branch
                moveTo(w * 0.95f, h * 0.10f)
                cubicTo(w * 0.80f, h * 0.25f, w * 0.65f, h * 0.38f, w * 0.35f, h * 0.65f)
                cubicTo(w * 0.25f, h * 0.75f, w * 0.15f, h * 0.85f, 0f, h * 0.95f)
            }
            drawPath(
                path = branchPath,
                color = Color(0xFF04060B),
                style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
            )

            // Leaf clusters along branch
            val leafCenters = listOf(
                Offset(w * 0.70f, h * 0.28f), Offset(w * 0.60f, h * 0.35f),
                Offset(w * 0.50f, h * 0.44f), Offset(w * 0.42f, h * 0.52f),
                Offset(w * 0.32f, h * 0.60f)
            )
            leafCenters.forEach { lc ->
                drawOval(
                    color = Color(0xFF04060A),
                    topLeft = Offset(lc.x - 18.dp.toPx(), lc.y - 10.dp.toPx()),
                    size = Size(36.dp.toPx(), 20.dp.toPx())
                )
            }
        }

        // 6. Red Heart Icon at Bottom Right of Frame
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 120.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .width(300.dp)
                    .height(300.dp),
                contentAlignment = Alignment.BottomEnd
            ) {
                Icon(
                    imageVector = Icons.Rounded.Favorite,
                    contentDescription = "Heart",
                    tint = Color(0xFFFF2D55),
                    modifier = Modifier
                        .size(32.dp)
                        .padding(end = 12.dp, bottom = 12.dp)
                )
            }
        }
    }
}

// --------------------------------------------------------------------------------------------------
// THEME 2: Foggy City (Misty Sunset/Street light + Silhouette + Sound Wave + Heart)
// --------------------------------------------------------------------------------------------------
@Composable
fun FoggyCityThemeView(isPlaying: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "FoggyCityAnim")

    // Dynamic visualizer bars height
    val barPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28318f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "BarPhase"
    )

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF0F141E))) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // 1. Foggy city gradient background (Warm top glow to misty blue-grey)
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF131922),
                        Color(0xFF1E2838),
                        Color(0xFFE3C3A2), // Foggy sunset light breaking through
                        Color(0xFF2B3A4C),
                        Color(0xFF0D121B)
                    )
                )
            )

            // 2. Soft streetlamp/sun light glow in upper-middle
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFFFFF2D6).copy(alpha = 0.70f),
                        Color(0xFFE8C59C).copy(alpha = 0.30f),
                        Color.Transparent
                    ),
                    center = Offset(w * 0.5f, h * 0.35f),
                    radius = w * 0.4f
                ),
                center = Offset(w * 0.5f, h * 0.35f),
                radius = w * 0.4f
            )

            // 3. City Skyscrapers Silhouettes on left & right
            val skylineLeft = Path().apply {
                moveTo(0f, h)
                lineTo(0f, h * 0.15f)
                lineTo(w * 0.28f, h * 0.15f)
                lineTo(w * 0.28f, h * 0.40f)
                lineTo(w * 0.38f, h * 0.40f)
                lineTo(w * 0.38f, h)
                close()
            }
            drawPath(path = skylineLeft, color = Color(0xFF0B1017).copy(alpha = 0.85f))

            val skylineRight = Path().apply {
                moveTo(w, h)
                lineTo(w, h * 0.10f)
                lineTo(w * 0.78f, h * 0.10f)
                lineTo(w * 0.78f, h * 0.38f)
                lineTo(w * 0.65f, h * 0.38f)
                lineTo(w * 0.65f, h)
                close()
            }
            drawPath(path = skylineRight, color = Color(0xFF0B1017).copy(alpha = 0.85f))

            // 4. Center Square Frame Outline
            val frameMargin = w * 0.15f
            val frameTop = h * 0.20f
            val frameSize = w - (frameMargin * 2)

            drawRect(
                color = Color.Black,
                topLeft = Offset(frameMargin, frameTop),
                size = Size(frameSize, frameSize),
                style = Stroke(width = 3.5.dp.toPx())
            )

            // 5. Silhouette of Walking Figure at bottom street
            val figureCenter = Offset(w * 0.5f, h * 0.82f)
            // Head
            drawCircle(color = Color(0xFF05080C), radius = 8.dp.toPx(), center = Offset(figureCenter.x, figureCenter.y - 20.dp.toPx()))
            // Body
            drawRoundRect(
                color = Color(0xFF05080C),
                topLeft = Offset(figureCenter.x - 10.dp.toPx(), figureCenter.y - 10.dp.toPx()),
                size = Size(20.dp.toPx(), 35.dp.toPx()),
                cornerRadius = CornerRadius(4.dp.toPx())
            )
        }

        // 6. Sound Wave Visualizer Graphic + Heart Icon in Center (Matching Image 2)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 80.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Spacer(modifier = Modifier.height(110.dp))

            // Audio Waveform Graphic Bars (Black minimalist visualizer)
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.height(36.dp)
            ) {
                // Circle logo icon
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.GraphicEq,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Waveform vertical bars
                val barHeights = listOf(0.4f, 0.7f, 0.3f, 0.9f, 0.5f, 0.8f, 0.4f, 0.95f, 0.6f, 0.3f, 0.7f, 0.5f, 0.8f)
                barHeights.forEachIndexed { idx, hFactor ->
                    val animatedFactor = if (isPlaying) {
                        (hFactor + 0.3f * sin(barPhase + idx * 0.8f)).coerceIn(0.15f, 1f)
                    } else hFactor * 0.4f

                    Box(
                        modifier = Modifier
                            .width(4.dp)
                            .height((28 * animatedFactor).dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(Color.Black)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Solid Black Heart
            Icon(
                imageVector = Icons.Rounded.Favorite,
                contentDescription = "Heart",
                tint = Color.Black,
                modifier = Modifier.size(28.dp)
            )
        }
    }
}

// --------------------------------------------------------------------------------------------------
// THEME 3: Glowing Score Notes (Cinematic Sheet Music + Floating 3D Music Notes)
// --------------------------------------------------------------------------------------------------
@Composable
fun GlowingNotesThemeView(isPlaying: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "ScoreNotesAnim")

    val floatAnim by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28318f,
        animationSpec = infiniteRepeatable(
            animation = tween(3500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "FloatAnim"
    )

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF001F24))) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // 1. Dual-tone cinematic gradient (Teal Blue top left to Amber Gold bottom right)
            drawRect(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF00E5FF).copy(alpha = 0.30f),
                        Color(0xFF00363A),
                        Color(0xFF121212),
                        Color(0xFF4E2600).copy(alpha = 0.70f)
                    ),
                    center = Offset(w * 0.3f, h * 0.3f),
                    radius = w * 1.2f
                )
            )

            // Warm bottom right glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFFFFB74D).copy(alpha = 0.60f),
                        Color(0xFFFF8F00).copy(alpha = 0.20f),
                        Color.Transparent
                    ),
                    center = Offset(w * 0.85f, h * 0.75f),
                    radius = w * 0.7f
                ),
                center = Offset(w * 0.85f, h * 0.75f),
                radius = w * 0.7f
            )

            // 2. Perspective Stave Sheet Music Lines
            for (stave in 0 until 3) {
                val startY = h * (0.45f + stave * 0.18f)
                for (line in 0 until 5) {
                    val y = startY + line * 8.dp.toPx()
                    drawLine(
                        color = Color.White.copy(alpha = 0.25f),
                        start = Offset(0f, y - 20.dp.toPx()),
                        end = Offset(w, y + 20.dp.toPx()),
                        strokeWidth = 1.5.dp.toPx()
                    )
                }
            }
        }

        // 3. Floating 3D Musical Notes Overlay (Matching Image 3)
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            val note1Offset = if (isPlaying) (12 * sin(floatAnim)).dp else 0.dp
            val note2Offset = if (isPlaying) (14 * cos(floatAnim + 1.5f)).dp else 0.dp

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Note 1 (♪)
                Text(
                    text = "♪",
                    fontSize = 80.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFFFD54F),
                    style = androidx.compose.ui.text.TextStyle(
                        shadow = Shadow(Color(0xFF00E5FF), blurRadius = 16f)
                    ),
                    modifier = Modifier.offset(y = note1Offset, x = (-30).dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Note 2 (♫)
                Text(
                    text = "♫",
                    fontSize = 96.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFE0F7FA),
                    style = androidx.compose.ui.text.TextStyle(
                        shadow = Shadow(Color(0xFFFF8F00), blurRadius = 24f)
                    ),
                    modifier = Modifier.offset(y = note2Offset, x = 30.dp)
                )
            }
        }
    }
}

// --------------------------------------------------------------------------------------------------
// THEME 4: Headphones Wave (White Line-art Headphones + Center Sound Wave)
// --------------------------------------------------------------------------------------------------
@Composable
fun HeadphonesWaveThemeView(isPlaying: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "HeadphonesWaveAnim")

    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28318f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "WavePhase"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val cx = w / 2f
            val cy = h * 0.42f

            // 1. Headphones Headband (Arch)
            val headbandPath = Path().apply {
                moveTo(cx - 100.dp.toPx(), cy + 20.dp.toPx())
                cubicTo(
                    cx - 100.dp.toPx(), cy - 120.dp.toPx(),
                    cx + 100.dp.toPx(), cy - 120.dp.toPx(),
                    cx + 100.dp.toPx(), cy + 20.dp.toPx()
                )
            }
            drawPath(
                path = headbandPath,
                color = Color.White,
                style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
            )

            // Headband Cushion bumps
            for (b in -2..2) {
                drawCircle(
                    color = Color.White,
                    radius = 4.dp.toPx(),
                    center = Offset(cx + (b * 16).dp.toPx(), cy - 92.dp.toPx())
                )
            }

            // 2. Left Earcup Outline
            val leftCup = Path().apply {
                addRoundRect(
                    androidx.compose.ui.geometry.RoundRect(
                        rect = Rect(cx - 120.dp.toPx(), cy - 20.dp.toPx(), cx - 80.dp.toPx(), cy + 70.dp.toPx()),
                        cornerRadius = CornerRadius(16.dp.toPx())
                    )
                )
            }
            drawPath(path = leftCup, color = Color.White, style = Stroke(width = 3.dp.toPx()))

            // 3. Right Earcup Outline
            val rightCup = Path().apply {
                addRoundRect(
                    androidx.compose.ui.geometry.RoundRect(
                        rect = Rect(cx + 80.dp.toPx(), cy - 20.dp.toPx(), cx + 120.dp.toPx(), cy + 70.dp.toPx()),
                        cornerRadius = CornerRadius(16.dp.toPx())
                    )
                )
            }
            drawPath(path = rightCup, color = Color.White, style = Stroke(width = 3.dp.toPx()))
        }

        // 4. Center Audio Sound Wave Equalizer (Inside Headphones)
        Row(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .height(80.dp)
                .offset(y = (-40).dp)
        ) {
            val barHeights = listOf(0.2f, 0.4f, 0.7f, 0.9f, 0.5f, 1.0f, 0.6f, 0.8f, 0.4f, 0.9f, 0.3f, 0.6f, 0.2f)
            barHeights.forEachIndexed { i, factor ->
                val dynamicH = if (isPlaying) {
                    (factor + 0.35f * sin(wavePhase + i * 0.7f)).coerceIn(0.1f, 1f)
                } else factor * 0.3f

                Box(
                    modifier = Modifier
                        .width(4.dp)
                        .height((50 * dynamicH).dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(Color.White)
                )
            }
        }
    }
}

// --------------------------------------------------------------------------------------------------
// THEME 5: Music Collage (Monochrome Grid + Floating Player Frame Card)
// --------------------------------------------------------------------------------------------------
@Composable
fun DarkCollageThemeView(isPlaying: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "CollageAnim")

    val pulseGlow by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "PulseGlow"
    )

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF101010))) {
        // 1. Monochrome Grid background tiles
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceEvenly
        ) {
            for (row in 0..4) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    for (col in 0..2) {
                        Box(
                            modifier = Modifier
                                .size(100.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White.copy(alpha = 0.03f))
                                .border(1.dp, Color.White.copy(alpha = 0.06f), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if ((row + col) % 2 == 0) Icons.Rounded.Album else Icons.Rounded.Headphones,
                                contentDescription = null,
                                tint = Color.White.copy(alpha = 0.12f),
                                modifier = Modifier.size(40.dp)
                            )
                        }
                    }
                }
            }
        }

        // 2. Floating Smartphone Glassmorphic Frame in Center (Matching Image 5)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 60.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .width(280.dp)
                    .height(340.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(Color(0xFF222222).copy(alpha = 0.92f))
                    .border(1.5.dp, Color.White.copy(alpha = 0.20f), RoundedCornerShape(28.dp))
                    .padding(20.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Inner Screen Placeholder
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.Black),
                        contentAlignment = Alignment.Center
                    ) {
                        // Pulsing status dot
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(if (isPlaying) Color(0xFF2ECC71).copy(alpha = pulseGlow) else Color.Gray)
                        )
                    }

                    // Device label
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Phone", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Icon(Icons.Rounded.Cast, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                    }

                    // Timeline line
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.2f))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(if (isPlaying) 0.45f else 0.1f)
                                .background(Color.White)
                        )
                    }

                    // Playback icons row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.SkipPrevious, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                        Icon(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(32.dp))
                        Icon(Icons.Rounded.SkipNext, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                    }
                }
            }
        }
    }
}

// --------------------------------------------------------------------------------------------------
// PREMIUM THEME: Cyber Neon Feel (Vibrant Audio Spectrum Waves + Space Nebula Glow + Neon Heart)
// --------------------------------------------------------------------------------------------------
@Composable
fun CyberNeonFeelThemeView(isPlaying: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "CyberNeonAnim")

    // Wave phase animation for visualizer bars (active only when isPlaying)
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28318f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "WavePhase"
    )

    // Glow pulse for outer neon border
    val glowPulse by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "GlowPulse"
    )

    val currentWavePhase = if (isPlaying) wavePhase else 0f

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF060212))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // 1. Cosmic Deep Sky Gradient
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF060212),
                        Color(0xFF13062B),
                        Color(0xFF1B0A3A),
                        Color(0xFF0D031F),
                        Color(0xFF060111)
                    )
                )
            )

            // 2. Center Ambient Glowing Aura behind Album Art
            val auraCenter = Offset(w * 0.5f, h * 0.36f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFFBD00FF).copy(alpha = 0.35f * glowPulse),
                        Color(0xFF00F0FF).copy(alpha = 0.20f * glowPulse),
                        Color.Transparent
                    ),
                    center = auraCenter,
                    radius = w * 0.55f
                ),
                center = auraCenter,
                radius = w * 0.55f
            )

            // 3. Starry Nebula Dust Twinkling
            val starPositions = listOf(
                Offset(w * 0.12f, h * 0.08f), Offset(w * 0.88f, h * 0.12f),
                Offset(w * 0.22f, h * 0.22f), Offset(w * 0.80f, h * 0.28f),
                Offset(w * 0.08f, h * 0.52f), Offset(w * 0.92f, h * 0.58f),
                Offset(w * 0.18f, h * 0.72f), Offset(w * 0.82f, h * 0.78f)
            )
            starPositions.forEachIndexed { i, pos ->
                val alpha = (0.3f + 0.5f * sin(currentWavePhase + i * 1.5f)).coerceIn(0.1f, 1f)
                drawCircle(
                    color = if (i % 2 == 0) Color(0xFF00F0FF).copy(alpha = alpha) else Color(0xFFFF00D6).copy(alpha = alpha),
                    radius = 2.5f,
                    center = pos
                )
            }

            // 4. Left Neon Visualizer Waves (Magenta / Purple)
            val leftXStart = w * 0.04f
            val leftXEnd = w * 0.18f
            val barCount = 10
            val barSpacing = (leftXEnd - leftXStart) / barCount
            val centerY = h * 0.36f
            val maxBarH = h * 0.16f

            for (i in 0 until barCount) {
                val x = leftXStart + i * barSpacing
                val factor = listOf(0.3f, 0.6f, 0.9f, 0.4f, 0.8f, 0.5f, 1.0f, 0.7f, 0.4f, 0.8f)[i % 10]
                val hFactor = if (isPlaying) {
                    (factor + 0.35f * sin(currentWavePhase + i * 0.8f)).coerceIn(0.15f, 1f)
                } else factor * 0.35f

                val barH = maxBarH * hFactor
                val alpha = (0.6f + 0.4f * hFactor).coerceIn(0.3f, 1f)

                drawLine(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFFFF00D6).copy(alpha = alpha),
                            Color(0xFFBD00FF).copy(alpha = alpha),
                            Color(0xFF7000FF).copy(alpha = alpha * 0.5f)
                        )
                    ),
                    start = Offset(x, centerY - barH / 2f),
                    end = Offset(x, centerY + barH / 2f),
                    strokeWidth = 3.5.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }

            // 5. Right Neon Visualizer Waves (Cyan / Electric Blue)
            val rightXStart = w * 0.82f
            val rightXEnd = w * 0.96f
            val rightSpacing = (rightXEnd - rightXStart) / barCount

            for (i in 0 until barCount) {
                val x = rightXStart + i * rightSpacing
                val factor = listOf(0.7f, 0.4f, 0.8f, 1.0f, 0.5f, 0.9f, 0.3f, 0.8f, 0.6f, 0.3f)[i % 10]
                val hFactor = if (isPlaying) {
                    (factor + 0.35f * cos(currentWavePhase + i * 0.8f)).coerceIn(0.15f, 1f)
                } else factor * 0.35f

                val barH = maxBarH * hFactor
                val alpha = (0.6f + 0.4f * hFactor).coerceIn(0.3f, 1f)

                drawLine(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF00F0FF).copy(alpha = alpha),
                            Color(0xFF0080FF).copy(alpha = alpha),
                            Color(0xFF0033FF).copy(alpha = alpha * 0.5f)
                        )
                    ),
                    start = Offset(x, centerY - barH / 2f),
                    end = Offset(x, centerY + barH / 2f),
                    strokeWidth = 3.5.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }
        }
    }
}
