package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.ScannedSong
import com.example.data.repository.MusicRepository
import com.example.data.repository.MusicThemeRepository
import com.example.player.MusicPlayerManager
import com.example.player.PlayerState
import com.example.ui.theme.MusicTheme
import com.example.ui.theme.MusicThemeRegistry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.io.File

class MusicViewModel(
    application: Application,
    private val musicRepository: MusicRepository,
    private val musicPlayerManager: MusicPlayerManager,
    private val musicThemeRepository: MusicThemeRepository
) : AndroidViewModel(application) {

    // Themes logic
    val selectedThemeId: StateFlow<String> = musicThemeRepository.selectedThemeId
        .stateIn(viewModelScope, SharingStarted.Eagerly, "moonlight_night")

    val customThemeImageUri: StateFlow<String?> = musicThemeRepository.customThemeImageUri
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val currentTheme: StateFlow<MusicTheme> = combine(
        selectedThemeId,
        customThemeImageUri
    ) { themeId, imageUri ->
        MusicThemeRegistry.getThemeById(themeId, imageUri)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, MusicThemeRegistry.BuiltInThemes.first())

    fun selectTheme(themeId: String) {
        viewModelScope.launch {
            musicThemeRepository.saveSelectedThemeId(themeId)
        }
    }

    fun setCustomThemeImage(uriString: String?) {
        viewModelScope.launch {
            musicThemeRepository.saveCustomThemeImageUri(uriString)
            if (uriString != null) {
                musicThemeRepository.saveSelectedThemeId("custom_image")
            } else {
                musicThemeRepository.saveSelectedThemeId("moonlight_night")
            }
        }
    }

    // Favorites Logic
    private val sharedPrefs = application.getSharedPreferences("music_player_prefs", Context.MODE_PRIVATE)
    private val _favoriteSongIds = MutableStateFlow<Set<Long>>(emptySet())
    val favoriteSongIds: StateFlow<Set<Long>> = _favoriteSongIds

    init {
        val favs = sharedPrefs.getStringSet("favorites", emptySet()) ?: emptySet()
        _favoriteSongIds.value = favs.mapNotNull { it.toLongOrNull() }.toSet()
    }

    fun toggleFavorite(songId: Long) {
        val current = _favoriteSongIds.value.toMutableSet()
        if (current.contains(songId)) {
            current.remove(songId)
        } else {
            current.add(songId)
        }
        _favoriteSongIds.value = current
        sharedPrefs.edit().putStringSet("favorites", current.map { it.toString() }.toSet()).apply()
    }

    fun isFavorite(songId: Long): Boolean {
        return _favoriteSongIds.value.contains(songId)
    }

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning

    private val vaultDao = com.example.data.database.AppDatabase.getDatabase(getApplication()).vaultDao()
    private val vaultItems = vaultDao.getVaultItems()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _songs = MutableStateFlow<List<ScannedSong>>(emptyList())
    val songs: StateFlow<List<ScannedSong>> = combine(_songs, vaultItems) { songList, vaultList ->
        val vaultTitles = vaultList.map { it.title.lowercase() }.toSet()
        val vaultPaths = vaultList.map { it.path.lowercase() }.toSet()
        songList.filter { song ->
            val titleLower = song.title.lowercase()
            val pathLower = song.path.lowercase()
            !vaultTitles.contains(titleLower) &&
            !vaultPaths.contains(pathLower) &&
            !pathLower.contains("vidiopen_vault")
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Playback state flows delegated from MusicPlayerManager
    val currentPlayingSong: StateFlow<ScannedSong?> = musicPlayerManager.currentPlayingSong
    val isPlaying: StateFlow<Boolean> = musicPlayerManager.isPlaying
    val playerState: StateFlow<PlayerState> = musicPlayerManager.playerState
    val currentPosition: StateFlow<Long> = musicPlayerManager.currentPosition
    val duration: StateFlow<Long> = musicPlayerManager.duration
    val queue: StateFlow<List<ScannedSong>> = musicPlayerManager.queue
    val repeatMode: StateFlow<Int> = musicPlayerManager.repeatMode
    val shuffleModeEnabled: StateFlow<Boolean> = musicPlayerManager.shuffleModeEnabled
    val playbackSpeed: StateFlow<Float> = musicPlayerManager.playbackSpeed

    // Premium Audio Effects and Equalizer states
    val eqEnabled = MutableStateFlow(musicPlayerManager.audioEffectsManager.eqEnabled)
    val selectedPreset = MutableStateFlow(musicPlayerManager.audioEffectsManager.selectedPreset)
    val eqBands = MutableStateFlow(musicPlayerManager.audioEffectsManager.eqBands.clone())

    val bassBoostEnabled = MutableStateFlow(musicPlayerManager.audioEffectsManager.bassBoostEnabled)
    val bassBoostStrength = MutableStateFlow(musicPlayerManager.audioEffectsManager.bassBoostStrength)

    val virtualizerEnabled = MutableStateFlow(musicPlayerManager.audioEffectsManager.virtualizerEnabled)
    val virtualizerStrength = MutableStateFlow(musicPlayerManager.audioEffectsManager.virtualizerStrength)

    val loudnessEnabled = MutableStateFlow(musicPlayerManager.audioEffectsManager.loudnessEnabled)
    val loudnessGain = MutableStateFlow(musicPlayerManager.audioEffectsManager.loudnessGain)

    val balance = MutableStateFlow(musicPlayerManager.getBalance())
    val reverbPreset = MutableStateFlow(musicPlayerManager.audioEffectsManager.reverbPreset)

    // Premium Sleep Timer and Fading states
    val sleepTimerRemaining = musicPlayerManager.sleepTimerRemaining
    val sleepTimerMode = musicPlayerManager.sleepTimerMode

    val fadeInEnabled = musicPlayerManager.fadeInEnabled
    val fadeInDurationMs = musicPlayerManager.fadeInDurationMs
    val fadeOutEnabled = musicPlayerManager.fadeOutEnabled
    val fadeOutDurationMs = musicPlayerManager.fadeOutDurationMs

    // Categories
    val allSongs: StateFlow<List<ScannedSong>> = songs

    val albums: StateFlow<List<AlbumItem>> = songs.map { songList ->
        songList.groupBy { it.album ?: "Unknown Album" }
            .map { (albumName, songs) ->
                AlbumItem(
                    name = albumName,
                    artist = songs.firstOrNull()?.artist ?: "Unknown Artist",
                    artworkUri = songs.firstOrNull()?.artworkUri,
                    songs = songs,
                    totalSize = songs.sumOf { it.size },
                    totalDuration = songs.sumOf { it.duration }
                )
            }.sortedBy { it.name }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val artists: StateFlow<List<ArtistItem>> = songs.map { songList ->
        songList.groupBy { it.artist ?: "Unknown Artist" }
            .map { (artistName, songs) ->
                ArtistItem(
                    name = artistName,
                    songs = songs,
                    totalSize = songs.sumOf { it.size },
                    totalDuration = songs.sumOf { it.duration },
                    artworkUri = songs.firstOrNull()?.artworkUri
                )
            }.sortedBy { it.name }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val folders: StateFlow<List<FolderItem>> = songs.map { songList ->
        songList.groupBy { 
            val file = File(it.path)
            file.parentFile?.absolutePath ?: "Unknown"
        }.map { (folderPath, songs) ->
            FolderItem(
                name = File(folderPath).name,
                path = folderPath,
                songs = songs,
                totalSize = songs.sumOf { it.size },
                totalDuration = songs.sumOf { it.duration }
            )
        }.sortedBy { it.name }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentlyAdded: StateFlow<List<ScannedSong>> = songs.map { songList ->
        songList.sortedByDescending { it.dateAdded }.take(50)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        val initialCached = musicRepository.getCachedSongs()
        if (initialCached.isNotEmpty()) {
            _songs.value = initialCached
            musicPlayerManager.syncScannedSongs(initialCached)
        }
        scanMusicFiles()
    }

    fun scanMusicFiles(forceRefresh: Boolean = false) {
        viewModelScope.launch {
            if (_songs.value.isEmpty()) {
                val cached = musicRepository.getCachedSongs()
                if (cached.isNotEmpty()) {
                    _songs.value = cached
                    musicPlayerManager.syncScannedSongs(cached)
                } else {
                    _isScanning.value = true
                }
            }
            try {
                val scanned = musicRepository.scanAudio(forceRefresh = forceRefresh)
                _songs.value = scanned
                musicPlayerManager.syncScannedSongs(scanned)
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isScanning.value = false
            }
        }
    }

    // Playback Control Delegates
    fun playSong(song: ScannedSong, contextList: List<ScannedSong>) {
        musicPlayerManager.playSong(song, contextList)
    }

    fun togglePlayPause() = musicPlayerManager.togglePlayPause()
    fun play() = musicPlayerManager.play()
    fun pause() = musicPlayerManager.pause()
    fun next() = musicPlayerManager.next()
    fun previous() = musicPlayerManager.previous()
    fun stop() = musicPlayerManager.stop()
    fun seekTo(positionMs: Long) = musicPlayerManager.seekTo(positionMs)
    fun fastSeekForward() = musicPlayerManager.fastSeekForward()
    fun fastSeekBackward() = musicPlayerManager.fastSeekBackward()
    fun replay() = musicPlayerManager.replay()

    // Queue Control Delegates
    fun playNext(song: ScannedSong) = musicPlayerManager.playNext(song)
    fun addToQueue(song: ScannedSong) = musicPlayerManager.addToQueue(song)
    fun removeFromQueue(songId: Long) = musicPlayerManager.removeFromQueue(songId)
    fun clearQueue() = musicPlayerManager.clearQueue()
    fun reorderQueue(fromIndex: Int, toIndex: Int) = musicPlayerManager.reorderQueue(fromIndex, toIndex)

    // Play Mode Delegates
    fun setRepeatMode(mode: Int) = musicPlayerManager.setRepeatMode(mode)
    fun setShuffleMode(enabled: Boolean) = musicPlayerManager.setShuffleMode(enabled)
    fun setPlaybackSpeed(speed: Float) = musicPlayerManager.setPlaybackSpeed(speed)

    // Premium Equalizer and Audio Effects Actions
    fun setEqEnabled(enabled: Boolean) {
        musicPlayerManager.audioEffectsManager.eqEnabled = enabled
        eqEnabled.value = enabled
    }

    fun setEqBand(bandIndex: Int, gainDb: Int) {
        musicPlayerManager.audioEffectsManager.setEqBand(bandIndex, gainDb)
        eqBands.value = musicPlayerManager.audioEffectsManager.eqBands.clone()
        eqEnabled.value = musicPlayerManager.audioEffectsManager.eqEnabled
    }

    fun selectPreset(presetName: String) {
        musicPlayerManager.audioEffectsManager.selectedPreset = presetName
        selectedPreset.value = presetName
        eqBands.value = musicPlayerManager.audioEffectsManager.eqBands.clone()
        eqEnabled.value = musicPlayerManager.audioEffectsManager.eqEnabled
    }

    fun saveCustomPreset(name: String, bands: IntArray) {
        musicPlayerManager.audioEffectsManager.saveCustomPreset(name, bands)
    }

    fun getCustomPresetNames(): Set<String> {
        return musicPlayerManager.audioEffectsManager.getCustomPresetNames()
    }

    fun deleteCustomPreset(name: String) {
        musicPlayerManager.audioEffectsManager.deleteCustomPreset(name)
    }

    fun setBassBoostEnabled(enabled: Boolean) {
        musicPlayerManager.audioEffectsManager.bassBoostEnabled = enabled
        bassBoostEnabled.value = enabled
    }

    fun setBassBoostStrength(strength: Int) {
        musicPlayerManager.audioEffectsManager.bassBoostStrength = strength
        bassBoostStrength.value = strength
        bassBoostEnabled.value = musicPlayerManager.audioEffectsManager.bassBoostEnabled
    }

    fun setVirtualizerEnabled(enabled: Boolean) {
        musicPlayerManager.audioEffectsManager.virtualizerEnabled = enabled
        virtualizerEnabled.value = enabled
    }

    fun setVirtualizerStrength(strength: Int) {
        musicPlayerManager.audioEffectsManager.virtualizerStrength = strength
        virtualizerStrength.value = strength
        virtualizerEnabled.value = musicPlayerManager.audioEffectsManager.virtualizerEnabled
    }

    fun setLoudnessEnabled(enabled: Boolean) {
        musicPlayerManager.audioEffectsManager.loudnessEnabled = enabled
        loudnessEnabled.value = enabled
    }

    fun setLoudnessGain(gainDb: Float) {
        musicPlayerManager.audioEffectsManager.loudnessGain = gainDb
        loudnessGain.value = gainDb
        loudnessEnabled.value = musicPlayerManager.audioEffectsManager.loudnessEnabled
    }

    fun setBalance(bal: Float) {
        musicPlayerManager.setBalance(bal)
        balance.value = bal
    }

    fun setReverbPreset(preset: Short) {
        musicPlayerManager.audioEffectsManager.reverbPreset = preset
        reverbPreset.value = preset
    }

    fun setSleepTimer(minutes: Int?) {
        musicPlayerManager.setSleepTimer(minutes)
    }

    fun setSleepTimerEndOfSong() {
        musicPlayerManager.setSleepTimerEndOfSong()
    }

    fun setFadeInEnabled(enabled: Boolean) {
        musicPlayerManager.setFadeInEnabled(enabled)
    }

    fun setFadeInDuration(ms: Long) {
        musicPlayerManager.setFadeInDuration(ms)
    }

    fun setFadeOutEnabled(enabled: Boolean) {
        musicPlayerManager.setFadeOutEnabled(enabled)
    }

    fun setFadeOutDuration(ms: Long) {
        musicPlayerManager.setFadeOutDuration(ms)
    }
}

// Grouping classes representing nested structures
data class AlbumItem(
    val name: String,
    val artist: String,
    val artworkUri: String?,
    val songs: List<ScannedSong>,
    val totalSize: Long,
    val totalDuration: Long
)

data class ArtistItem(
    val name: String,
    val songs: List<ScannedSong>,
    val totalSize: Long,
    val totalDuration: Long,
    val artworkUri: String? = null
)

data class FolderItem(
    val name: String,
    val path: String,
    val songs: List<ScannedSong>,
    val totalSize: Long,
    val totalDuration: Long
)

class MusicViewModelFactory(
    private val application: Application,
    private val musicRepository: MusicRepository,
    private val musicPlayerManager: MusicPlayerManager,
    private val musicThemeRepository: MusicThemeRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MusicViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MusicViewModel(application, musicRepository, musicPlayerManager, musicThemeRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
