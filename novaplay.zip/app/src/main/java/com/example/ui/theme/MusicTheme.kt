package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

data class MusicTheme(
    val id: String,
    val name: String,
    val isDark: Boolean = true,
    val backgroundColor: Color = Color.Black,
    val backgroundBrush: Brush? = null,
    val accentColor: Color = Color(0xFF00D9FF),     // Used for sliders, progress indicators, active icons
    val primaryColor: Color = Color(0xFF7C4DFF),    // Used for main buttons, primary highlights
    val cardBackground: Color = Color(0x0FFFFFFF),  // Card background color
    val textColor: Color = Color.White,
    val subtitleColor: Color = Color(0xFF9E9E9E),
    val glassBorderColor: Color = Color(0x33FFFFFF),
    val bgImageUri: String? = null                  // Used if a custom image/photo background is set
) {
    // Helper to get actual background modifier brush
    fun getBgBrush(): Brush {
        return backgroundBrush ?: Brush.verticalGradient(listOf(backgroundColor, backgroundColor))
    }
}

object MusicThemeRegistry {
    val BuiltInThemes = listOf(
        // 1. Cinematic Theme
        MusicTheme(
            id = "cinematic",
            name = "Cinematic",
            backgroundColor = Color(0xFF0C0804),
            backgroundBrush = Brush.verticalGradient(
                listOf(Color(0xFF0D0804), Color(0xFF1E1308), Color(0xFF090603))
            ),
            accentColor = Color(0xFFFFB800),     // Rich Amber Gold
            primaryColor = Color(0xFFF59E0B),    // Cinematic Warm Gold
            cardBackground = Color(0x33261607),
            glassBorderColor = Color(0x66FFB800)
        ),
        // 2. Music Feel Theme
        MusicTheme(
            id = "music_feel",
            name = "Music Feel",
            backgroundColor = Color(0xFF080114),
            backgroundBrush = Brush.verticalGradient(
                listOf(Color(0xFF080114), Color(0xFF180336), Color(0xFF05000F))
            ),
            accentColor = Color(0xFF00F0FF),     // Electric Cyan
            primaryColor = Color(0xFFFF007F),    // Neon Magenta
            cardBackground = Color(0x3322053F),
            glassBorderColor = Color(0x6600F0FF)
        ),
        // 3. Nature Theme
        MusicTheme(
            id = "nature",
            name = "Nature",
            backgroundColor = Color(0xFF02120A),
            backgroundBrush = Brush.verticalGradient(
                listOf(Color(0xFF02120A), Color(0xFF062B16), Color(0xFF010E07))
            ),
            accentColor = Color(0xFF00E676),     // Vivid Emerald
            primaryColor = Color(0xFF84CC16),    // Forest Leaf Green
            cardBackground = Color(0x33062B17),
            glassBorderColor = Color(0x5500E676)
        ),
        // 4. Night Theme
        MusicTheme(
            id = "night",
            name = "Night",
            backgroundColor = Color(0xFF030712),
            backgroundBrush = Brush.verticalGradient(
                listOf(Color(0xFF030712), Color(0xFF08122B), Color(0xFF02040B))
            ),
            accentColor = Color(0xFF38BDF8),     // Starlight Sky Blue
            primaryColor = Color(0xFF818CF8),    // Twilight Violet
            cardBackground = Color(0x330C1938),
            glassBorderColor = Color(0x5538BDF8)
        ),
        // 5. Night or Cinematic or Moon ek sath Theme
        MusicTheme(
            id = "night_cinematic_moon",
            name = "Night Cinematic Moon",
            backgroundColor = Color(0xFF030612),
            backgroundBrush = Brush.verticalGradient(
                listOf(Color(0xFF020617), Color(0xFF0D1730), Color(0xFF040816))
            ),
            accentColor = Color(0xFFFDE68A),     // Golden Lunar Halo
            primaryColor = Color(0xFF6366F1),    // Deep Celestial Violet
            cardBackground = Color(0x33111827),
            glassBorderColor = Color(0x66FDE68A)
        ),
        MusicTheme(
            id = "cyber_neon_feel",
            name = "Feel The Music (Cyber Neon)",
            backgroundColor = Color(0xFF070210),
            backgroundBrush = Brush.verticalGradient(
                listOf(Color(0xFF060212), Color(0xFF13062C), Color(0xFF080119))
            ),
            accentColor = Color(0xFF00F0FF),  // Electric Cyan
            primaryColor = Color(0xFFBD00FF), // Neon Purple/Pink
            cardBackground = Color(0x331D0836),
            glassBorderColor = Color(0x66BD00FF)
        ),
        MusicTheme(
            id = "moonlight_night",
            name = "Moonlight Night",
            backgroundBrush = Brush.verticalGradient(
                listOf(Color(0xFF080B12), Color(0xFF101626))
            ),
            accentColor = Color(0xFFFF3366),
            primaryColor = Color(0xFFE0E0E0),
            cardBackground = Color(0x22101626),
            glassBorderColor = Color(0x44FFFFFF)
        ),
        MusicTheme(
            id = "foggy_city",
            name = "Foggy City",
            backgroundBrush = Brush.verticalGradient(
                listOf(Color(0xFF0C0F17), Color(0xFF1E2838), Color(0xFF10141D))
            ),
            accentColor = Color(0xFF111111),
            primaryColor = Color(0xFFE8C59C),
            cardBackground = Color(0x22000000),
            glassBorderColor = Color(0x33000000)
        ),
        MusicTheme(
            id = "glowing_notes",
            name = "Glowing Notes",
            backgroundBrush = Brush.verticalGradient(
                listOf(Color(0xFF00363A), Color(0xFF0A192F), Color(0xFF3E2723))
            ),
            accentColor = Color(0xFFFFB74D),
            primaryColor = Color(0xFF00E5FF),
            cardBackground = Color(0x2200E5FF),
            glassBorderColor = Color(0x44FFB74D)
        ),
        MusicTheme(
            id = "headphones_wave",
            name = "Headphones Wave",
            backgroundColor = Color(0xFF000000),
            accentColor = Color(0xFFFFFFFF),
            primaryColor = Color(0xFFE0E0E0),
            cardBackground = Color(0xFF121212),
            glassBorderColor = Color(0x33FFFFFF)
        ),
        MusicTheme(
            id = "dark_collage",
            name = "Music Collage",
            backgroundColor = Color(0xFF121212),
            backgroundBrush = Brush.verticalGradient(
                listOf(Color(0xFF181818), Color(0xFF0A0A0A))
            ),
            accentColor = Color(0xFFFFFFFF),
            primaryColor = Color(0xFF888888),
            cardBackground = Color(0xFF242424),
            glassBorderColor = Color(0x33FFFFFF)
        )
    )

    fun getThemeById(id: String, customUri: String? = null): MusicTheme {
        if (id == "custom_image" && customUri != null) {
            return MusicTheme(
                id = "custom_image",
                name = "Favorite Image",
                backgroundColor = Color.Black.copy(alpha = 0.5f), // Translucent overlay to see the image
                accentColor = Color(0xFF00D9FF),
                primaryColor = Color(0xFF7C4DFF),
                cardBackground = Color(0x2A000000),
                glassBorderColor = Color(0x22FFFFFF),
                bgImageUri = customUri
            )
        }
        return BuiltInThemes.find { it.id == id } ?: BuiltInThemes.first()
    }
}
