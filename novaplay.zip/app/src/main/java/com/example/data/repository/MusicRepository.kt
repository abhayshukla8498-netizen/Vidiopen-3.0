package com.example.data.repository

import android.content.ContentUris
import android.content.Context
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import com.example.data.model.ScannedSong
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File

class MusicRepository(private val context: Context) {

    @Volatile
    private var cachedSongs: List<ScannedSong>? = null
    @Volatile
    private var lastScanTimestamp: Long = 0L

    fun getCachedSongs(): List<ScannedSong> {
        return cachedSongs ?: emptyList()
    }

    private val audioExtensions = setOf(
        "mp3", "m4a", "aac", "flac", "wav", "ogg", "opus", "wma",
        "m4p", "mid", "amr", "aiff", "alac", "3gp", "webm"
    )

    private fun isRingtoneOrSystemAudio(
        path: String,
        title: String,
        isRingtone: Boolean = false,
        isNotification: Boolean = false,
        isAlarm: Boolean = false,
        isMusic: Boolean = true,
        durationMs: Long = 0L
    ): Boolean {
        // Explicit MediaStore flags
        if (isRingtone || isNotification || isAlarm) return true

        val lowerPath = path.lowercase()
        val lowerTitle = title.lowercase()
        val fileName = path.substringAfterLast('/').lowercase()

        // Explicit path checks for system audio or ringtone directories
        if (lowerPath.contains("/system/media/") ||
            lowerPath.contains("/system/audio/") ||
            lowerPath.contains("/ringtones/") ||
            lowerPath.contains("/ringtone/") ||
            lowerPath.contains("/notifications/") ||
            lowerPath.contains("/notification/") ||
            lowerPath.contains("/alarms/") ||
            lowerPath.contains("/alarm/") ||
            lowerPath.contains("/audiotrimmer/") ||
            (lowerPath.contains("android/data/") && lowerPath.contains("ringtones"))
        ) {
            return true
        }

        // Filename / title checks
        if (fileName.startsWith("ringtone_") ||
            fileName.contains("_ringtone") ||
            fileName.startsWith("notification_") ||
            fileName.startsWith("alarm_") ||
            lowerTitle.startsWith("ringtone_") ||
            lowerTitle.contains("_ringtone")
        ) {
            return true
        }

        // Short audio clip filter (< 15 seconds) that contain ringtone keywords or are not flagged as music
        if (durationMs in 1..14999L) {
            if (!isMusic || lowerPath.contains("ringtone") || lowerPath.contains("notification") || lowerTitle.contains("ringtone")) {
                return true
            }
        }

        return false
    }

    suspend fun scanAudio(forceRefresh: Boolean = false): List<ScannedSong> = withContext(Dispatchers.IO) {
        val currentCache = cachedSongs
        val now = System.currentTimeMillis()
        if (!forceRefresh && currentCache != null && (now - lastScanTimestamp < 5000L)) {
            return@withContext currentCache
        }

        val songMap = LinkedHashMap<String, ScannedSong>()
        val newScanPaths = mutableListOf<String>()

        // 1. High-speed Indexed MediaStore Audio Query (Instant SQLite index query)
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.IS_RINGTONE,
            MediaStore.Audio.Media.IS_NOTIFICATION,
            MediaStore.Audio.Media.IS_ALARM,
            MediaStore.Audio.Media.IS_MUSIC
        )

        try {
            val audioUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            context.contentResolver.query(
                audioUri,
                projection,
                "${MediaStore.Audio.Media.SIZE} > 10240",
                null,
                "${MediaStore.Audio.Media.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndex(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)
                val albumCol = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM)
                val durationCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION)
                val sizeCol = cursor.getColumnIndex(MediaStore.Audio.Media.SIZE)
                val pathCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)
                val dateAddedCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATE_ADDED)
                val albumIdCol = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID)
                val nameCol = cursor.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME)
                val isRingtoneCol = cursor.getColumnIndex(MediaStore.Audio.Media.IS_RINGTONE)
                val isNotifCol = cursor.getColumnIndex(MediaStore.Audio.Media.IS_NOTIFICATION)
                val isAlarmCol = cursor.getColumnIndex(MediaStore.Audio.Media.IS_ALARM)
                val isMusicCol = cursor.getColumnIndex(MediaStore.Audio.Media.IS_MUSIC)

                while (cursor.moveToNext()) {
                    val path = if (pathCol != -1) cursor.getString(pathCol) ?: "" else ""
                    if (path.isEmpty()) continue

                    val size = if (sizeCol != -1) cursor.getLong(sizeCol) else 0L
                    if (size < 10240L) continue

                    val ext = path.substringAfterLast('.', "").lowercase()
                    if (ext.isNotEmpty() && !audioExtensions.contains(ext) && !ext.contains("mp3")) continue

                    val isRingtone = isRingtoneCol != -1 && cursor.getInt(isRingtoneCol) == 1
                    val isNotif = isNotifCol != -1 && cursor.getInt(isNotifCol) == 1
                    val isAlarm = isAlarmCol != -1 && cursor.getInt(isAlarmCol) == 1
                    val isMusic = isMusicCol == -1 || cursor.getInt(isMusicCol) == 1
                    val durationVal = if (durationCol != -1) cursor.getLong(durationCol) else 0L

                    var title = if (titleCol != -1) cursor.getString(titleCol) else null
                    if (title.isNullOrBlank() || title == MediaStore.UNKNOWN_STRING) {
                        val dispName = if (nameCol != -1) cursor.getString(nameCol) else null
                        title = if (!dispName.isNullOrBlank()) {
                            dispName.substringBeforeLast('.')
                        } else {
                            path.substringAfterLast('/').substringBeforeLast('.')
                        }
                    }

                    if (isRingtoneOrSystemAudio(
                            path = path,
                            title = title,
                            isRingtone = isRingtone,
                            isNotification = isNotif,
                            isAlarm = isAlarm,
                            isMusic = isMusic,
                            durationMs = durationVal
                        )
                    ) {
                        continue
                    }

                    val canonicalKey = path.lowercase()
                    if (songMap.containsKey(canonicalKey)) continue

                    val id = if (idCol != -1) cursor.getLong(idCol) else Math.abs(canonicalKey.hashCode().toLong())
                    val artistVal = if (artistCol != -1) cursor.getString(artistCol) else null
                    val artist = if (artistVal.isNullOrBlank() || artistVal == MediaStore.UNKNOWN_STRING) "Unknown Artist" else artistVal

                    val albumVal = if (albumCol != -1) cursor.getString(albumCol) else null
                    val album = if (albumVal.isNullOrBlank() || albumVal == MediaStore.UNKNOWN_STRING) "Unknown Album" else albumVal

                    val dateAdded = if (dateAddedCol != -1 && cursor.getLong(dateAddedCol) > 0) cursor.getLong(dateAddedCol) else System.currentTimeMillis() / 1000
                    val albumId = if (albumIdCol != -1) cursor.getLong(albumIdCol) else 0L

                    val artworkUri = if (albumId > 0) {
                        ContentUris.withAppendedId(
                            Uri.parse("content://media/external/audio/albumart"),
                            albumId
                        ).toString()
                    } else null

                    songMap[canonicalKey] = ScannedSong(
                        id = id,
                        title = title,
                        artist = artist,
                        album = album,
                        duration = if (durationVal > 0) durationVal else 180000L,
                        size = size,
                        path = path,
                        dateAdded = dateAdded,
                        albumId = albumId,
                        artworkUri = artworkUri
                    )
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "MusicRepository: Error querying audio collection")
        }

        // 2. Query MediaStore.Files for any audio files or MP3s not indexed in Audio.Media (e.g. downloads, chats)
        try {
            val fileCollection = MediaStore.Files.getContentUri("external")
            val fileProjection = arrayOf(
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DATA,
                MediaStore.Files.FileColumns.SIZE,
                MediaStore.Files.FileColumns.DATE_MODIFIED,
                MediaStore.Files.FileColumns.DISPLAY_NAME,
                MediaStore.Files.FileColumns.TITLE
            )
            val fileSelection = "(${MediaStore.Files.FileColumns.MEDIA_TYPE} = ${MediaStore.Files.FileColumns.MEDIA_TYPE_AUDIO} OR " +
                    "${MediaStore.Files.FileColumns.MIME_TYPE} LIKE 'audio/%' OR " +
                    "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE '%.mp3' OR " +
                    "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE '%.m4a' OR " +
                    "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE '%.aac' OR " +
                    "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE '%.flac' OR " +
                    "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE '%.wav' OR " +
                    "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE '%.opus') AND ${MediaStore.Files.FileColumns.SIZE} > 10240"

            context.contentResolver.query(
                fileCollection,
                fileProjection,
                fileSelection,
                null,
                "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndex(MediaStore.Files.FileColumns._ID)
                val pathCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DATA)
                val sizeCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.SIZE)
                val dateCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DATE_MODIFIED)
                val nameCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME)
                val titleCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.TITLE)

                while (cursor.moveToNext()) {
                    val path = if (pathCol != -1) cursor.getString(pathCol) ?: "" else ""
                    if (path.isEmpty()) continue

                    val canonicalKey = path.lowercase()
                    if (songMap.containsKey(canonicalKey)) continue

                    val ext = path.substringAfterLast('.', "").lowercase()
                    if (!audioExtensions.contains(ext) && !ext.contains("mp3")) continue

                    val size = if (sizeCol != -1) cursor.getLong(sizeCol) else 0L
                    if (size < 10240L) continue

                    val name = if (nameCol != -1) cursor.getString(nameCol) else null
                    val titleVal = if (titleCol != -1) cursor.getString(titleCol) else null
                    val title = if (!titleVal.isNullOrBlank()) {
                        titleVal
                    } else if (!name.isNullOrBlank()) {
                        name.substringBeforeLast('.')
                    } else {
                        path.substringAfterLast('/').substringBeforeLast('.')
                    }

                    if (isRingtoneOrSystemAudio(path, title)) continue

                    val dateAdded = if (dateCol != -1 && cursor.getLong(dateCol) > 0) cursor.getLong(dateCol) else System.currentTimeMillis() / 1000
                    val id = if (idCol != -1) cursor.getLong(idCol) else Math.abs(canonicalKey.hashCode().toLong())

                    songMap[canonicalKey] = ScannedSong(
                        id = id,
                        title = title,
                        artist = "Unknown Artist",
                        album = "Unknown Album",
                        duration = 180000L,
                        size = size,
                        path = path,
                        dateAdded = dateAdded,
                        albumId = 0L,
                        artworkUri = null
                    )
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "MusicRepository: Error querying MediaStore Files")
        }

        // 3. Fast Targeted Scan of Common Audio/Download Directories (Shallow & Instant, max 1 level)
        try {
            val candidateDirs = mutableListOf<File>()
            val musicDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
            if (musicDir != null && musicDir.exists()) candidateDirs.add(musicDir)
            val downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (downloadDir != null && downloadDir.exists()) candidateDirs.add(downloadDir)

            val root = Environment.getExternalStorageDirectory()
            if (root != null && root.exists()) {
                val subFolderNames = listOf(
                    "Music", "Download", "Downloads", "Audio", "Bluetooth", "Snaptube/download/Audio",
                    "Vidmate/download", "WhatsApp/Media/WhatsApp Audio", "Telegram/Telegram Audio", "VidiopenAudio"
                )
                for (name in subFolderNames) {
                    val d = File(root, name)
                    if (d.exists() && d.isDirectory) {
                        candidateDirs.add(d)
                    }
                }
            }

            val checkedDirs = mutableSetOf<String>()
            for (dir in candidateDirs) {
                val dirKey = dir.absolutePath.lowercase()
                if (!checkedDirs.add(dirKey)) continue

                val files = dir.listFiles() ?: continue
                for (f in files) {
                    if (f.isFile && f.length() > 10240L) {
                        val ext = f.extension.lowercase()
                        if (audioExtensions.contains(ext) || ext.contains("mp3")) {
                            val pathKey = f.absolutePath.lowercase()
                            if (!songMap.containsKey(pathKey)) {
                                val title = f.nameWithoutExtension
                                if (!isRingtoneOrSystemAudio(f.absolutePath, title)) {
                                    songMap[pathKey] = ScannedSong(
                                        id = Math.abs(pathKey.hashCode().toLong()),
                                        title = title,
                                        artist = "Unknown Artist",
                                        album = "Unknown Album",
                                        duration = 180000L,
                                        size = f.length(),
                                        path = f.absolutePath,
                                        dateAdded = f.lastModified() / 1000,
                                        albumId = 0L,
                                        artworkUri = null
                                    )
                                    newScanPaths.add(f.absolutePath)
                                }
                            }
                        }
                    } else if (f.isDirectory && !f.name.startsWith(".") && f.name != "Android") {
                        // Quick 1-level subfolder check (e.g., Download/Album1/)
                        val subFiles = f.listFiles() ?: continue
                        for (sub in subFiles) {
                            if (sub.isFile && sub.length() > 10240L) {
                                val ext = sub.extension.lowercase()
                                if (audioExtensions.contains(ext) || ext.contains("mp3")) {
                                    val subKey = sub.absolutePath.lowercase()
                                    if (!songMap.containsKey(subKey)) {
                                        val title = sub.nameWithoutExtension
                                        if (!isRingtoneOrSystemAudio(sub.absolutePath, title)) {
                                            songMap[subKey] = ScannedSong(
                                                id = Math.abs(subKey.hashCode().toLong()),
                                                title = title,
                                                artist = "Unknown Artist",
                                                album = "Unknown Album",
                                                duration = 180000L,
                                                size = sub.length(),
                                                path = sub.absolutePath,
                                                dateAdded = sub.lastModified() / 1000,
                                                albumId = 0L,
                                                artworkUri = null
                                            )
                                            newScanPaths.add(sub.absolutePath)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "MusicRepository: Error in fast directory scan")
        }

        // Asynchronously notify MediaScanner in background for newly discovered files so OS indexes them
        if (newScanPaths.isNotEmpty()) {
            try {
                MediaScannerConnection.scanFile(
                    context,
                    newScanPaths.take(50).toTypedArray(),
                    null,
                    null
                )
            } catch (e: Exception) {
                Timber.w(e, "MusicRepository: MediaScannerConnection async notification bypassed")
            }
        }

        val sortedList = songMap.values.toList().sortedByDescending { it.dateAdded }
        cachedSongs = sortedList
        lastScanTimestamp = System.currentTimeMillis()
        sortedList
    }
}

