package com.example.data.model

import android.net.Uri

enum class WhatsAppType(val title: String, val packageName: String) {
    WHATSAPP("WhatsApp", "com.whatsapp"),
    WHATSAPP_BUSINESS("WA Business", "com.whatsapp.w4b")
}

enum class StatusFilter(val title: String) {
    ALL("All"),
    VIDEOS("Videos"),
    PHOTOS("Photos"),
    SAVED("Saved")
}

data class WhatsAppStatus(
    val id: String,
    val uri: Uri,
    val title: String,
    val isVideo: Boolean,
    val size: Long,
    val lastModified: Long,
    val isSaved: Boolean = false,
    val isBusiness: Boolean = false,
    val localFilePath: String? = null
)
