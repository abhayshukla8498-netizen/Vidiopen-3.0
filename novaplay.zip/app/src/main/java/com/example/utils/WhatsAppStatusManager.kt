package com.example.utils

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import com.example.data.model.WhatsAppStatus
import com.example.data.model.WhatsAppType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object WhatsAppStatusManager {

    private const val PREFS_NAME = "vidiopen_status_saver_prefs"
    private const val KEY_WA_TREE_URI = "key_whatsapp_tree_uri"
    private const val KEY_WB_TREE_URI = "key_whatsapp_business_tree_uri"

    private const val SAVED_FOLDER_VIDEOS = "Movies/Vidiopen Statuses"
    private const val SAVED_FOLDER_IMAGES = "Pictures/Vidiopen Statuses"

    fun getPersistedTreeUri(context: Context, type: WhatsAppType): Uri? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val key = if (type == WhatsAppType.WHATSAPP) KEY_WA_TREE_URI else KEY_WB_TREE_URI
        val uriString = prefs.getString(key, null) ?: return null
        return try {
            Uri.parse(uriString)
        } catch (e: Exception) {
            null
        }
    }

    fun savePersistedTreeUri(context: Context, type: WhatsAppType, uri: Uri) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val key = if (type == WhatsAppType.WHATSAPP) KEY_WA_TREE_URI else KEY_WB_TREE_URI
        prefs.edit().putString(key, uri.toString()).apply()
    }

    /**
     * Checks if WhatsApp or WhatsApp Business is installed with multi-layer verification
     * ensuring Android 11+ Package Visibility does not produce false negatives.
     */
    fun isAppInstalled(context: Context, packageName: String): Boolean {
        val pm = context.packageManager

        // 1. Check getLaunchIntentForPackage
        try {
            if (pm.getLaunchIntentForPackage(packageName) != null) {
                return true
            }
        } catch (_: Exception) {}

        // 2. Check getPackageInfo
        try {
            pm.getPackageInfo(packageName, 0)
            return true
        } catch (_: Exception) {}

        // 3. Fallback check for known WhatsApp variants if checking generic WhatsApp
        val fallbackPackages = if (packageName.contains("w4b")) {
            listOf("com.whatsapp.w4b")
        } else {
            listOf("com.whatsapp", "com.gbwhatsapp", "com.fmwhatsapp", "com.yowhatsapp", "com.whatsapp.plus")
        }
        for (pkg in fallbackPackages) {
            try {
                if (pm.getLaunchIntentForPackage(pkg) != null) return true
            } catch (_: Exception) {}
            try {
                pm.getPackageInfo(pkg, 0)
                return true
            } catch (_: Exception) {}
        }

        // 4. Check queryIntentActivities with launcher intent
        try {
            val intent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
                setPackage(packageName)
            }
            val resolves = pm.queryIntentActivities(intent, 0)
            if (resolves.isNotEmpty()) {
                return true
            }
        } catch (_: Exception) {}

        // 5. Check file directory presence (if WhatsApp was ever installed, directories exist)
        val ext = Environment.getExternalStorageDirectory()
        val mediaDirs = listOf(
            File(ext, "Android/media/$packageName"),
            File(ext, "Android/media/$packageName/WhatsApp/Media/.Statuses"),
            File(ext, "Android/media/$packageName/WhatsApp Business/Media/.Statuses"),
            File(ext, "WhatsApp/Media/.Statuses"),
            File(ext, "WhatsApp Business/Media/.Statuses"),
            File("/storage/emulated/0/Android/media/$packageName"),
            File("/storage/emulated/999/Android/media/$packageName")
        )
        if (mediaDirs.any { it.exists() }) {
            return true
        }

        return false
    }

    /**
     * Checks if All Files Access (Android 11+) or Storage Permission is granted
     */
    fun isStorageAccessGranted(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            androidx.core.content.ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.READ_EXTERNAL_STORAGE
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        }
    }

    /**
     * Intent to open Android 11+ Manage All Files Access screen for this app
     */
    fun getManageStorageIntent(context: Context): Intent {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                    data = Uri.parse("package:${context.packageName}")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            } catch (_: Exception) {
                Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }
        } else {
            Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        }
    }

    /**
     * Creates an Intent to launch SAF folder picker directly at WhatsApp's .Statuses folder.
     */
    fun createOpenDocumentTreeIntent(isBusiness: Boolean): Intent {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val subPath = if (isBusiness) {
                "Android%2Fmedia%2Fcom.whatsapp.w4b%2FWhatsApp%20Business%2FMedia%2F.Statuses"
            } else {
                "Android%2Fmedia%2Fcom.whatsapp%2FWhatsApp%2FMedia%2F.Statuses"
            }
            val uri = Uri.parse("content://com.android.externalstorage.documents/document/primary%3A$subPath")
            intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, uri)
        }
        return intent
    }

    /**
     * Returns true if status is an image or video (ignoring .nomedia or other files)
     */
    private fun isValidStatusFile(name: String?): Boolean {
        if (name.isNullOrEmpty() || name.startsWith(".")) return false
        val lower = name.lowercase()
        return lower.endsWith(".mp4") || lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png") || lower.endsWith(".gif")
    }

    private fun isVideoFile(name: String?): Boolean {
        if (name == null) return false
        val lower = name.lowercase()
        return lower.endsWith(".mp4") || lower.endsWith(".mkv") || lower.endsWith(".3gp")
    }

    /**
     * Get list of direct file directories to inspect for WhatsApp Statuses across all Android versions
     */
    private fun getDirectDirectories(type: WhatsAppType): List<File> {
        val dirs = mutableListOf<File>()
        val baseRoots = listOf(
            Environment.getExternalStorageDirectory(),
            File("/storage/emulated/0"),
            File("/sdcard")
        )

        for (base in baseRoots) {
            if (type == WhatsAppType.WHATSAPP) {
                dirs.add(File(base, "Android/media/com.whatsapp/WhatsApp/Media/.Statuses"))
                dirs.add(File(base, "Android/media/com.whatsapp/WhatsApp/media/.Statuses"))
                dirs.add(File(base, "Android/media/com.whatsapp/WhatsApp/Media/.statuses"))
                dirs.add(File(base, "WhatsApp/Media/.Statuses"))
                dirs.add(File(base, "WhatsApp/media/.Statuses"))
                dirs.add(File(base, "WhatsApp/Media/.statuses"))
                dirs.add(File("/storage/emulated/999/Android/media/com.whatsapp/WhatsApp/Media/.Statuses"))
            } else {
                dirs.add(File(base, "Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses"))
                dirs.add(File(base, "Android/media/com.whatsapp.w4b/WhatsApp Business/media/.Statuses"))
                dirs.add(File(base, "Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.statuses"))
                dirs.add(File(base, "WhatsApp Business/Media/.Statuses"))
                dirs.add(File(base, "WhatsApp Business/media/.Statuses"))
                dirs.add(File(base, "WhatsApp Business/Media/.statuses"))
            }
        }
        return dirs.distinct()
    }

    /**
     * Scan statuses from direct files or DocumentFile tree URI
     */
    suspend fun loadStatuses(context: Context, type: WhatsAppType): List<WhatsAppStatus> = withContext(Dispatchers.IO) {
        val result = mutableListOf<WhatsAppStatus>()
        val savedTitles = getSavedStatusFileNames()
        val seenKeys = mutableSetOf<String>()

        // 1. First attempt: Direct File system access
        val directDirs = getDirectDirectories(type)

        for (dir in directDirs) {
            try {
                if (dir.exists() && dir.isDirectory) {
                    val files = dir.listFiles()
                    if (!files.isNullOrEmpty()) {
                        for (file in files) {
                            if (isValidStatusFile(file.name) && file.length() > 0) {
                                if (seenKeys.add(file.name)) {
                                    val isVid = isVideoFile(file.name)
                                    result.add(
                                        WhatsAppStatus(
                                            id = file.absolutePath,
                                            uri = Uri.fromFile(file),
                                            title = file.name,
                                            isVideo = isVid,
                                            size = file.length(),
                                            lastModified = file.lastModified(),
                                            isSaved = savedTitles.contains(file.name),
                                            isBusiness = type == WhatsAppType.WHATSAPP_BUSINESS,
                                            localFilePath = file.absolutePath
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Timber.w(e, "Could not list directory: ${dir.absolutePath}")
            }
        }

        // 2. Second attempt: DocumentFile Tree URI if SAF permission was granted
        val treeUri = getPersistedTreeUri(context, type)
        if (treeUri != null) {
            try {
                val root = DocumentFile.fromTreeUri(context, treeUri)
                if (root != null && root.isDirectory) {
                    val docFiles = root.listFiles()
                    for (doc in docFiles) {
                        val name = doc.name ?: continue
                        if (isValidStatusFile(name) && doc.length() > 0) {
                            if (seenKeys.add(name)) {
                                val isVid = isVideoFile(name)
                                result.add(
                                    WhatsAppStatus(
                                        id = doc.uri.toString(),
                                        uri = doc.uri,
                                        title = name,
                                        isVideo = isVid,
                                        size = doc.length(),
                                        lastModified = doc.lastModified(),
                                        isSaved = savedTitles.contains(name),
                                        isBusiness = type == WhatsAppType.WHATSAPP_BUSINESS,
                                        localFilePath = null
                                    )
                                )
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Timber.w(e, "Tree URI access error")
            }
        }

        // Sort by newest first
        result.sortedByDescending { it.lastModified }
    }

    /**
     * Get list of saved statuses in Vidiopen Statuses folder
     */
    suspend fun loadSavedStatuses(context: Context): List<WhatsAppStatus> = withContext(Dispatchers.IO) {
        val result = mutableListOf<WhatsAppStatus>()
        val seenPaths = mutableSetOf<String>()

        val checkDirs = listOf(
            File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "Vidiopen Statuses"),
            File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Vidiopen Statuses"),
            File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Vidiopen/WhatsAppStatus"),
            File(Environment.getExternalStorageDirectory(), SAVED_FOLDER_VIDEOS),
            File(Environment.getExternalStorageDirectory(), SAVED_FOLDER_IMAGES)
        )

        for (dir in checkDirs) {
            try {
                if (dir.exists() && dir.isDirectory) {
                    dir.listFiles()?.filter { isValidStatusFile(it.name) && it.length() > 0 }?.forEach { file ->
                        if (seenPaths.add(file.name)) {
                            result.add(
                                WhatsAppStatus(
                                    id = file.absolutePath,
                                    uri = Uri.fromFile(file),
                                    title = file.name,
                                    isVideo = isVideoFile(file.name),
                                    size = file.length(),
                                    lastModified = file.lastModified(),
                                    isSaved = true,
                                    isBusiness = false,
                                    localFilePath = file.absolutePath
                                )
                            )
                        }
                    }
                }
            } catch (_: Exception) {}
        }

        result.sortedByDescending { it.lastModified }
    }

    private fun getSavedStatusFileNames(): Set<String> {
        val names = mutableSetOf<String>()
        val checkDirs = listOf(
            File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "Vidiopen Statuses"),
            File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Vidiopen Statuses"),
            File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Vidiopen/WhatsAppStatus"),
            File(Environment.getExternalStorageDirectory(), SAVED_FOLDER_VIDEOS),
            File(Environment.getExternalStorageDirectory(), SAVED_FOLDER_IMAGES)
        )
        for (dir in checkDirs) {
            try {
                if (dir.exists() && dir.isDirectory) {
                    dir.listFiles()?.forEach { file ->
                        names.add(file.name)
                        names.add(file.name.substringBeforeLast("_"))
                    }
                }
            } catch (_: Exception) {}
        }
        return names
    }

    /**
     * 1-Click Status Download: Saves status permanently to Gallery & public directories with zero errors
     */
    suspend fun saveStatusToGallery(context: Context, status: WhatsAppStatus): Boolean = withContext(Dispatchers.IO) {
        try {
            val isVid = status.isVideo
            val ext = if (isVid) ".mp4" else ".jpg"
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val baseName = status.title.substringBeforeLast(".").replace("[^a-zA-Z0-9_-]".toRegex(), "_")
            val cleanTitle = "${baseName}_$timeStamp$ext"

            // Extract bytes with multi-layer fallback
            val inputBytes = getBytesForStatus(context, status) ?: return@withContext false
            if (inputBytes.isEmpty()) return@withContext false

            var savedSuccessfully = false

            // 1. Direct Public Folder Save (Pictures/Vidiopen Statuses or Movies/Vidiopen Statuses)
            try {
                val publicDir = Environment.getExternalStoragePublicDirectory(
                    if (isVid) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
                )
                val targetDir = File(publicDir, "Vidiopen Statuses")
                if (!targetDir.exists()) targetDir.mkdirs()

                val targetFile = File(targetDir, cleanTitle)
                FileOutputStream(targetFile).use { fos ->
                    fos.write(inputBytes)
                    fos.flush()
                }

                MediaScannerConnection.scanFile(
                    context,
                    arrayOf(targetFile.absolutePath),
                    arrayOf(if (isVid) "video/mp4" else "image/jpeg"),
                    null
                )
                savedSuccessfully = true
            } catch (e: Exception) {
                Timber.w(e, "Direct public save fallback error")
            }

            // 2. Extra backup in Downloads/Vidiopen/WhatsAppStatus
            try {
                val dlDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Vidiopen/WhatsAppStatus")
                if (!dlDir.exists()) dlDir.mkdirs()
                val dlFile = File(dlDir, cleanTitle)
                FileOutputStream(dlFile).use { fos ->
                    fos.write(inputBytes)
                    fos.flush()
                }
                MediaScannerConnection.scanFile(context, arrayOf(dlFile.absolutePath), arrayOf(if (isVid) "video/mp4" else "image/jpeg"), null)
                savedSuccessfully = true
            } catch (_: Exception) {}

            // 3. Android Q+ Scoped Storage MediaStore Insert
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                try {
                    val resolver = context.contentResolver
                    val contentValues = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, cleanTitle)
                        put(MediaStore.MediaColumns.MIME_TYPE, if (isVid) "video/mp4" else "image/jpeg")
                        put(
                            MediaStore.MediaColumns.RELATIVE_PATH,
                            if (isVid) SAVED_FOLDER_VIDEOS else SAVED_FOLDER_IMAGES
                        )
                        put(MediaStore.MediaColumns.IS_PENDING, 1)
                    }

                    val collection = if (isVid) {
                        MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    } else {
                        MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    }

                    val itemUri = resolver.insert(collection, contentValues)
                    if (itemUri != null) {
                        resolver.openOutputStream(itemUri)?.use { out ->
                            out.write(inputBytes)
                            out.flush()
                        }
                        contentValues.clear()
                        contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                        resolver.update(itemUri, contentValues, null, null)
                        savedSuccessfully = true
                    }
                } catch (e: Exception) {
                    Timber.w(e, "MediaStore insertion failed")
                }
            }

            savedSuccessfully
        } catch (e: Exception) {
            Timber.e(e, "saveStatusToGallery failed")
            false
        }
    }

    private fun getBytesForStatus(context: Context, status: WhatsAppStatus): ByteArray? {
        // 1. Try direct local File path first
        if (!status.localFilePath.isNullOrBlank()) {
            try {
                val file = File(status.localFilePath)
                if (file.exists() && file.length() > 0) {
                    val bytes = file.readBytes()
                    if (bytes.isNotEmpty()) return bytes
                }
            } catch (_: Exception) {}
        }

        // 2. Try URI file path if scheme is file://
        if (status.uri.scheme == "file" || status.uri.path?.startsWith("/") == true) {
            try {
                val path = status.uri.path
                if (path != null) {
                    val file = File(path)
                    if (file.exists() && file.length() > 0) {
                        val bytes = file.readBytes()
                        if (bytes.isNotEmpty()) return bytes
                    }
                }
            } catch (_: Exception) {}
        }

        // 3. Try ContentResolver via URI
        try {
            context.contentResolver.openInputStream(status.uri)?.use { stream ->
                val bytes = stream.readBytes()
                if (bytes.isNotEmpty()) return bytes
            }
        } catch (_: Exception) {}

        // 4. Try DocumentFile single URI
        try {
            val doc = DocumentFile.fromSingleUri(context, status.uri)
            if (doc != null && doc.exists()) {
                context.contentResolver.openInputStream(doc.uri)?.use { stream ->
                    val bytes = stream.readBytes()
                    if (bytes.isNotEmpty()) return bytes
                }
            }
        } catch (_: Exception) {}

        return null
    }

    /**
     * Share status to external apps
     */
    fun shareStatus(context: Context, status: WhatsAppStatus, targetPackage: String? = null) {
        try {
            val shareUri: Uri = if (status.localFilePath != null) {
                val file = File(status.localFilePath)
                FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            } else {
                status.uri
            }

            val mimeType = if (status.isVideo) "video/mp4" else "image/*"
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, shareUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                if (targetPackage != null) {
                    setPackage(targetPackage)
                }
            }

            val chooser = if (targetPackage == null) {
                Intent.createChooser(intent, "Share Status via")
            } else {
                intent
            }
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        } catch (e: Exception) {
            try {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = if (status.isVideo) "video/*" else "image/*"
                    putExtra(Intent.EXTRA_STREAM, status.uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(Intent.createChooser(intent, "Share Status"))
            } catch (ex: Exception) {
                ex.printStackTrace()
            }
        }
    }
}
