package com.example.utils

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.media.ThumbnailUtils
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import androidx.core.graphics.drawable.toDrawable
import coil.ImageLoader
import coil.decode.DataSource
import coil.fetch.DrawableResult
import coil.fetch.FetchResult
import coil.fetch.Fetcher
import coil.request.Options
import coil.size.Dimension
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Fast in-memory LRU cache for video thumbnails to ensure silky 60fps/120fps scrolling
 * without repeated disk reads, Binder IPC calls, or frame decoding overhead.
 */
object VideoThumbnailMemoryCache {
    private val maxMemory = (Runtime.getRuntime().maxMemory() / 1024).toInt()
    private val cacheSize = (maxMemory / 8).coerceIn(16 * 1024, 64 * 1024)

    val cache = object : LruCache<String, Bitmap>(cacheSize) {
        override fun sizeOf(key: String, value: Bitmap): Int {
            return value.byteCount / 1024
        }
    }

    fun clear() {
        cache.evictAll()
    }
}

class VideoThumbnailFetcher(
    private val context: Context,
    private val data: Uri,
    private val options: Options
) : Fetcher {

    override suspend fun fetch(): FetchResult? = withContext(Dispatchers.IO) {
        val cacheKey = data.toString()

        // 1. Instant Memory Cache Hit
        val cached = VideoThumbnailMemoryCache.cache.get(cacheKey)
        if (cached != null && !cached.isRecycled) {
            return@withContext DrawableResult(
                drawable = cached.toDrawable(context.resources),
                isSampled = false,
                dataSource = DataSource.MEMORY
            )
        }

        // 2. Decode thumbnail efficiently
        val bitmap: Bitmap? = try {
            val scheme = data.scheme
            val pathStr = data.path ?: ""
            if (scheme == ContentResolver.SCHEME_CONTENT || data.toString().startsWith("content://")) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val widthPx = (options.size.width as? Dimension.Pixels)?.px ?: 240
                    val heightPx = (options.size.height as? Dimension.Pixels)?.px ?: 160
                    context.contentResolver.loadThumbnail(
                        data,
                        Size(widthPx.coerceIn(80, 280), heightPx.coerceIn(60, 180)),
                        null
                    )
                } else {
                    val id = try { ContentUris.parseId(data) } catch (e: Exception) { -1L }
                    if (id != -1L) {
                        MediaStore.Video.Thumbnails.getThumbnail(
                            context.contentResolver,
                            id,
                            MediaStore.Video.Thumbnails.MICRO_KIND,
                            null
                        )
                    } else null
                }
            } else if (scheme == ContentResolver.SCHEME_FILE || pathStr.startsWith("/")) {
                val filePath = if (scheme == ContentResolver.SCHEME_FILE) data.path else data.toString()
                if (!filePath.isNullOrEmpty()) {
                    val file = java.io.File(filePath)
                    if (file.exists()) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            ThumbnailUtils.createVideoThumbnail(
                                file,
                                Size(240, 160),
                                null
                            )
                        } else {
                            @Suppress("DEPRECATION")
                            ThumbnailUtils.createVideoThumbnail(
                                filePath,
                                MediaStore.Images.Thumbnails.MICRO_KIND
                            )
                        }
                    } else null
                } else null
            } else null
        } catch (e: Exception) {
            null
        }

        if (bitmap != null) {
            // Save to memory cache for zero-latency instant future hits
            VideoThumbnailMemoryCache.cache.put(cacheKey, bitmap)
            DrawableResult(
                drawable = bitmap.toDrawable(context.resources),
                isSampled = true,
                dataSource = DataSource.DISK
            )
        } else {
            null
        }
    }

    class Factory(private val context: Context) : Fetcher.Factory<Uri> {
        override fun create(data: Uri, options: Options, imageLoader: ImageLoader): Fetcher? {
            val str = data.toString()
            val scheme = data.scheme
            val path = data.path ?: ""
            val isVideo = (scheme == ContentResolver.SCHEME_CONTENT && str.contains("video")) ||
                    path.endsWith(".mp4", ignoreCase = true) ||
                    path.endsWith(".mkv", ignoreCase = true) ||
                    path.endsWith(".webm", ignoreCase = true) ||
                    path.endsWith(".3gp", ignoreCase = true) ||
                    path.endsWith(".avi", ignoreCase = true) ||
                    str.endsWith(".mp4", ignoreCase = true)
            
            if (isVideo) {
                return VideoThumbnailFetcher(context, data, options)
            }
            return null
        }
    }
}
